from django.contrib import admin
from .models import *


class TypeInfoAdmin(admin.ModelAdmin):
    '''商品类别在admin界面中的表示形式'''
    list_display = ['id','ttitle']                     #显示的属性

class GoodsInfoAdmin(admin.ModelAdmin):
    '''商品信息在admin界面中的表示形式'''
    list_per_page = 15                                 #每页显示的条数
    list_display = [                                   #显示的属性
        'id',
        'gtitle',
        'gunit',
        'gclick',
        'gstock',
        'gtypeinfo'

    ]

#注册
admin.site.register(TypeInfo,TypeInfoAdmin)
admin.site.register(GoodsInfo,GoodsInfoAdmin)
