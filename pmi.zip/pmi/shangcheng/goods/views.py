from django.shortcuts import render,redirect
from django.http import *
from .models import *
from django.core.urlresolvers import reverse
from hashlib import sha1
from django.template import loader,RequestContext
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from django.db.models import *
from cart.models import *


def index(request):
    '''
    跳转到首页
    准备数据：
    1、各分类的最新四条数据
    2、各分类最热四条数据
    '''
    typelist = TypeInfo.objects.all()                             #查询所有类型

    type0 = typelist[0].goodsinfo_set.order_by('-id')[0:4]        #第一个类别下所有商品按照id倒序，取前四个
    type01 = typelist[0].goodsinfo_set.order_by('-gclick')[0:4]   #第一个类别下所有商品按照点击量倒序，取前四个

    type1 = typelist[1].goodsinfo_set.order_by('-id')[0:4]
    type11 = typelist[1].goodsinfo_set.order_by('-gclick')[0:4]

    type2 = typelist[2].goodsinfo_set.order_by('-id')[0:4]
    type21 = typelist[2].goodsinfo_set.order_by('-gclick')[0:4]

    type3 = typelist[3].goodsinfo_set.order_by('-id')[0:4]
    type31 = typelist[3].goodsinfo_set.order_by('-gclick')[0:4]

    type4 = typelist[4].goodsinfo_set.order_by('-id')[0:4]
    type41 = typelist[4].goodsinfo_set.order_by('-gclick')[0:4]

    type5 = typelist[5].goodsinfo_set.order_by('-id')[0:4]
    type51 = typelist[5].goodsinfo_set.order_by('-gclick')[0:4]
    context = {
        'title': '首页',
        'page_name':2,
        'type0':type0, 'type01':type01,
        'type1': type1, 'type11': type11,
        'type2': type2, 'type21': type21,
        'type3': type3, 'type31': type31,
        'type4': type4, 'type41': type41,
        'type5': type5, 'type51': type51,
        'cart_count':cart_count(request)   #购物车的数量，待完成
    }
    return render(request, 'goods/index.html',context)



def detail(request,id):
    '''
    跳转到详情页面
    '''
    goods=GoodsInfo.objects.get(pk=int(id))                          #根据id查询商品
    goods.gclick=goods.gclick+1                                      #点击量+1
    goods.save()                                                     #更新，更新点击量

    news=goods.gtypeinfo.goodsinfo_set.order_by('-id')[0:2]          #查询当前产品所在类别最新的两个

    context = {                                                      #数据字典
        'title':goods.gtypeinfo.ttitle,
        'page_name':2,
        'g':goods,
        'news':news,
        'id':id,
        'cart_count':cart_count(request)   #购物车的数量，待完成

    }
    responce = render(request,'goods/detail.html',context)            #设置并返回responce对象

    #设置浏览记录
    goods_ids = request.COOKIES.get('goods_ids','')                   #获取COOKIE,如果获取不到，返回''。设置浏览记录，用户中心使用
    if goods_ids != '':                                               #判断是否有浏览记录，如果有则继续判断
        goods_ids1 = goods_ids.split(',')                             #拆分为列表
        if goods_ids1.count(id) >= 1:                                 #如果商品以经被记录，则删除
            goods_ids1.remove(id)
        goods_ids1.insert(0, id)                                      #添加到第一个
        if len(goods_ids1) >= 6:                                      #如果达到6个则删除最后一个，因为最近浏览是5个
            del goods_ids1[5]
        goods_ids = ','.join(goods_ids1)                              #拼接为字符串
    else:
        goods_ids = str(id)                                           #如果没有浏览记录则直接加
    responce.set_cookie('goods_ids',goods_ids)                        #写入cookie

    return responce                                                   #返回响应


def list(request,tid,pindex,sort):
    '''
    列出当前分类信息，按要求分页

    :param request:        类型编号 1 2 3 4 5 6 分别表示不同类型 与数据库中的id保持一致
    :param tid：           当前页码
    :param sort:           排序方式 1(最新，默认) 2(价格) 3(点击量)
    :return:
    '''
    typeinfo=TypeInfo.objects.get(pk=int(tid))                                           #获取类型编号
    news=typeinfo.goodsinfo_set.order_by('-id')[0:2]                                     #推荐本类中最新的两个商品
    if sort == '1':
        goods_list=GoodsInfo.objects.filter(gtypeinfo_id=int(tid)).order_by('-id')       #本类最新
    elif sort == '2':
        goods_list = GoodsInfo.objects.filter(gtypeinfo_id=int(tid)).order_by('gprice')  #本类价格从低到高
    elif sort == '3':
        goods_list = GoodsInfo.objects.filter(gtypeinfo_id=int(tid)).order_by('-gclick') #本类点击量从高到低

    paginator=Paginator(goods_list,15)                                                   #设置分页对象
    page=paginator.page(int(pindex))                                                     #设置当前页信息

    context = {
        'title':typeinfo.ttitle,
        'page_name': 2,
        'page':page,
        'paginator':paginator,
        'typeinfo':typeinfo,
        'sort':sort,
        'news':news,
        'cart_count':cart_count(request)   #购物车的数量，待完成
    }
    return render(request, 'goods/list.html',context)



def find(request):
    '''
       模糊查询
       查询标题或者内容
    '''
    keyword = request.GET.get('keyword','').strip()                             #获取查询的关键字
    sort = request.GET.get('sort','1')                                          #排序方式
    pindex = request.GET.get('pindex','1')                                      #排序方式

    goods_list = GoodsInfo.objects.filter(                                      #根据标题和内容模糊查询
        Q(gtitle__icontains=keyword) |
        Q(gcontent__icontains=keyword) |
        Q(gintroduction__icontains=keyword)

    )

    if sort=='1':
        goods_list=goods_list.order_by('-id')                                   #最新
    elif sort=='2':
        goods_list = goods_list.order_by('gprice')                              #价格从高到低
    elif sort=='3':
        goods_list = goods_list.order_by('-gclick')                             #点击量从高到低

    news = GoodsInfo.objects.all().order_by('-id')[0:2]                         #最新的两个

    paginator = Paginator(goods_list, 15)                                       #分页对象
    page = paginator.page(int(pindex))                                          #当前页的对象

    context = {
        'title':'搜索商品',
        'page_name': 2,
        'page': page,
        'paginator':paginator,
        'typeinfo':None,
        'sort': sort,
        'news': news,
        'keyword':keyword,
        'cart_count':cart_count(request)   #购物车的数量，待完成
    }
    return render(request, 'goods/find.html', context)


def cart_count(request):
    '''
    计算目前购物车里商品购买的数量
    :param request:
    :return:
    '''

    count = 0                                                           #储存用户购买商品,如果没有登录，默认是0

    user_id = request.session.get('user_id')                        #获取session里用户id
    if user_id:                                                         #判断
        ret = CartInfo.objects.filter(userinfo_id=user_id).aggregate(num=Sum('count'))   #求数量
        count = ret['num']

    return count

def luckdraw(request):
    return render(request,'goods/luckdraw.html')