from django.conf.urls import include, url
from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^(\d+)/$', views.detail, name='detail'),
    url(r'^list/(\d+)/(\d+)/(\d+)/$', views.list, name='list'),
    url(r'^find/$', views.find, name='find'),
    url(r'^cart_count/$', views.cart_count, name='cart_count'),
    url(r'^luckdraw/$', views.luckdraw, name='luckdraw'),
]
