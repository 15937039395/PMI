from django.conf.urls import include, url
from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^$', views.order,name='order'),                               #购物车提交订单
    url(r'^order_handle/$',views.order_handle,name='order_handle'),    #新增订单信息
    url(r'^show(\d*)/$', views.show,name='show'),                               #显示订单信息
    url(r'^pay(\d+)/$', views.pay,name='pay'),                               #显示付款



]
