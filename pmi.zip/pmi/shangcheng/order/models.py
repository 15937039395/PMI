from django.db import models
from user.models import *

class OrderInfo(models.Model):
    '''订单信息'''
    oid=models.CharField(max_length=20,primary_key=True)                #订单编号
    userinfo=models.ForeignKey(UserInfo)                                #用户
    odate=models.DateTimeField(auto_now_add=True)                       #日期
    oispay=models.BooleanField(default=False)                           #是否已付款
    ototal=models.DecimalField(max_digits=10,decimal_places=2)          #金额
    oaddress=models.CharField(max_length=150)                           #地址


class OrderDetailInfo(models.Model):
    '''订单明细'''
    goodsinfo=models.ForeignKey('goods.GoodsInfo')                      #商品
    orderinfo=models.ForeignKey(OrderInfo)                              #订单
    price=models.DecimalField(max_digits=10,decimal_places=2)           #价格
    count=models.IntegerField()                                         #数量
