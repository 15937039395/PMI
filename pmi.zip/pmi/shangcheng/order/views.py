from django.shortcuts import render,redirect
from user import user_decorator
from user.models import *
from goods.models import *
from cart.models import *
from django.db import transaction
from .models import *
from datetime import *
from django.core.paginator import Paginator,Page

@user_decorator.login
def order(request):
    '''跳转到订单页面'''
    user=UserInfo.objects.get(id=request.session['user_id'])                  #查询用户
    cart_ids=request.GET.getlist('cart_ids')                                  #获取购物车id列表，每个都是字符串类型
    cart_ids2=[int(item) for item in cart_ids]                                #转成int类型组合成的列表
    carts=CartInfo.objects.filter(id__in=cart_ids2)                            #查询
    cart_ids=','.join(cart_ids)                                               #逗号连接成一个字符串
    context={
        'title':'提交订单',
        'page_name':1,
        'carts':carts,
        'user':user,
        'cart_ids':cart_ids
    }
    return render(request,'order/place_order.html',context)




'''
事务：同生共死

1、创建订单对象
2、判断商品的库存
3、创建订单对象
4、修改商品库存
5、删除购物车

事务设计原则
1、保持事务短小
2、尽量避免事务中rollback
3、尽量避免savepoint
4、默认情况下，依赖于悲观锁
5、为吞吐量要求苛刻的事务考虑乐观锁
6、显示声明打开事务
7、锁的行为越少越好，锁的时间越短越好
'''



@user_decorator.login
@transaction.atomic
def order_handle(request):
    '''新增订单'''
    tran_id=transaction.savepoint()                          #设置事务的保存点，可以回滚到这里

    cart_ids=request.POST.get('cart_ids')                    #接收购物车编号

    try:
        order=OrderInfo()                                    #创建订单对象
        now=datetime.now()                                   #当前时间
        uid=request.session['user_id']                       #获取用户id
        order.oid='%s%d'%(now.strftime('%Y%m%d%H%M%S'),uid)  #设置订单编号的算法：当前时间+用户的id
        order.userinfo_id=uid                                #设置订单对象的属性
        order.odate=now
        order.oaddress=request.POST.get('address')
        order.ototal=0                                       #后面会再更新
        order.save()                                         #新增订单，为后面新增订单明细做准备

        #num=1/0                                             #模拟异常

        cart_ids1=[int(item) for item in cart_ids.split(',')] #设置并获取int类型id组合的列表
        total=0                                               #存储商品价格总计
        for id1 in cart_ids1:                                 #遍历
            detail=OrderDetailInfo()                          #创建订单明细对象
            detail.orderinfo=order                            #设置订单明细对象的属性
            cart=CartInfo.objects.get(id=id1)                 #根据id获取购物车对象
            goods=cart.goodsinfo                              #获取此购物车商品对象
            if goods.gstock>=cart.count:                      #判断库存，如果库存大于购买数量
                goods.gstock=goods.gstock-cart.count          #减少商品库存
                goods.save()                                  #更新

                detail.goodsinfo=goods                        #设置订单明细对象的属性：商品
                detail.price=goods.gprice                     #设置订单明细对象的属性：价格
                detail.count=cart.count                       #设置订单明细对象的属性：数量
                detail.save()                                 #新增

                total=total+goods.gprice*cart.count           #计算总计
                cart.delete()                                 #删除购物车数据
            else:                                             #如果库存小于购买数量
                transaction.savepoint_rollback(tran_id)       #回滚，到上一次的保存点
                return redirect('/cart/')                     #重定向到购物车页面

        order.ototal=total+10                                 #保存总价：商品总价+邮费
        order.save()                                          #更新总价
        transaction.savepoint_commit(tran_id)                 #提交，保存点到目前的代码功能
    except Exception as e:
        print('异常：%s'%e)                                    #打印异常，也可以记录到日志中
        transaction.savepoint_rollback(tran_id)               #回滚，到上一次的保存点
        # raise e

    return redirect('/order/show/')                          #重定向到订单页面

@user_decorator.login
def show(request,pindex):
    '''
    分页显示订单信息
    :param request:
    :param pindex: 页码
    :return:
    '''
    user_id = request.session['user_id']                    #获取session里用户id
    order_list=OrderInfo.objects.filter(userinfo_id=user_id).order_by('-oid') #查找此用户的订单，并按照id倒叙
    paginator=Paginator(order_list,2)                       #获取分页对象，每页显示两条
    if pindex=='':                                          #判断默认值
        pindex='1'
    page=paginator.page(int(pindex))                        #当前页对象

    context={
        'title':'用户中心',
        'page_name':1,
        'paginator':paginator,
        'page':page,
    }
    return render(request,'user/user_center_order.html',context)


@user_decorator.login
def pay(request,oid):
    '''
    付款
    :param request:
    :param oid:   订单的编号
    :return:
    '''
    order=OrderInfo.objects.get(oid=oid)                        #根据id获取对象
    order.oispay=True                                           #修改属性
    order.save()                                                #更新
    context={'order':order}                                     #准备数据
    return render(request,'order/pay.html',context)             #到付款页面
































