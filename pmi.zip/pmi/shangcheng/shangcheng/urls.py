from django.conf.urls import include, url
from django.contrib import admin

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^user/', include('user.urls',namespace="user")),
    url(r'^', include('goods.urls',namespace="goods")),
    url(r'^tinymce/', include('tinymce.urls',namespace="tinymce")),
    url(r'^cart/', include('cart.urls',namespace="cart")),
    url(r'^order/', include('order.urls',namespace="order")),

 ]
