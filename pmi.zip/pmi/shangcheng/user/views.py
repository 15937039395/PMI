from django.shortcuts import render,redirect
from django.http import *
from .models import *
from django.core.urlresolvers import reverse
from hashlib import sha1
from django.template import loader,RequestContext
from django.core.paginator import Paginator,Page
from . import user_decorator
from goods.models import *
from order.models import *






def register(request):
    #跳转到用户注册页面
    context = {'title':'用户注册'}
    return render(request,'user/register.html',context)

def register_handel(request):
    '''
    处理用户注册
    如果成功跳转到用户登录页面
    否则跳转到注册页面，并显示错误信息
    '''
    #接收用户输入
    post = request.POST
    uname = post.get('user_name')
    upwd = post.get('pwd')
    upwd2 = post.get('cpwd')
    uemail = post.get('email')
    #判断两次密码
    if upwd != upwd2:
        return redirect('/user/register.html')
    #密码加密
    s1 = sha1()
    s1.update(upwd.encode('utf-8'))
    upwd3 = s1.hexdigest()
    #创建对象
    user = UserInfo()
    user.uname = uname
    user.upwd = upwd3
    user.uemail = uemail

    user.save()
    #注册成功,转到登录页面
    return redirect('/user/login/')

def check_name(request):
    '''检查用户名是否可用  1 可用  0不可用'''
    ret = 0
    uname = request.POST.get('uname')
    if len(UserInfo.objects.filter(uname=uname))==0:
        ret = 1
    return HttpResponse(ret)

def login(request):
    '''用户登录'''
    uname=request.COOKIES.get('uname','')
    context={'title':'用户登录','error_name':0,'error_pwd':0,'uname':uname}
    return render(request,'user/login.html',context)


def login_handel(request):
     # 接收请求信息
     post = request.POST
     uname = post.get('username')
     upwd = post.get('pwd')
     rememberName = post.get('rememberName',0)
     #根据用户名查找对象
     users = UserInfo.objects.filter(uname=uname)
     if len(users) == 1:
         s1=sha1()
         s1.update(upwd.encode('utf-8'))
         if s1.hexdigest()==users[0].upwd:
             url=request.COOKIES.get('url','/')
             red=HttpResponseRedirect(url)
             #成功后删除转向地址，防止以后直接登录造成的转向
             red.set_cookie('url','',max_age=-1)
             #记住用户名
             if rememberName != 0:
                 red.set_cookie('uname',uname)
             else:
                 red.set_cookie('uname','',max_age=-1)
             #登录成功保存session信息
             request.session['user_id']=users[0].id
             request.session['user_name']=uname
             return red
         else:

             context={'title':'用户登录','error_name':0,'error_pwd':1,'uname':uname,'upwd':upwd}

             return render(request,'user/login.html',context)
     else:

         context = {'title': '用户登录', 'error_name': 1, 'error_pwd': 0, 'uname': uname, 'upwd': upwd}

         return render(request, 'user/login.html',context)

def logout(request):
    '''
    退出登录清空session
    '''
    request.session.flush()
    return redirect('/')

@user_decorator.login
def info(request):
    '''
    个人信息
    '''
    # 第二种方式
    user = UserInfo.objects.get(id=request.session['user_id'])                 #根据session里储存的id查找当前用户
    #第一种方式
    # user_email=UserInfo.objects.get(id=request.session['user_id']).uemail
    goods_list = []
    goods_ids = request.COOKIES.get('goods_ids', '')                           # 获取COOKIE,如果获取不到，返回''。设置浏览记录，用户中心使用
    if goods_ids != '':                                                        # 判断是否有浏览记录，如果有则继续判断
        goods_ids1 = goods_ids.split(',')                                      # 分割得到id数据
        #GoodsInfo.objects.filter(id_in=goods_ids1)
        for goods_id in goods_ids1:
            goods_list.append(GoodsInfo.objects.get(id=int(goods_id)))
    context = {
        'title': '用户中心',
        'user':user,
        # 第一种方式
        # 'user_email': user_email,
        # 'user_name':request.session['user_name'],
        'page_name': 1,
        'goods_list':goods_list
        }
    return render(request,'user/user_center_info.html',context)


@user_decorator.login
def site(request):
    user=UserInfo.objects.get(id=request.session['user_id'])

    if request.method=='POST':
        post=request.POST
        user.ureceive=post.get('ureceive')
        user.uaddress = post.get('uaddress')
        user.uzipcode = post.get('uzipcode')
        user.uphone = post.get('uphone')
        user.save()
    context = {
        'title': '用户中心',
        'user': user,
        'page_name': 1,
    }

    return render(request, 'user/user_center_site.html', context)

def user_center_order(request):
    user = UserInfo.objects.get(id=request.session['user_id'])                   # 根据session里存储的id查找当前用户
    user_id = request.session['user_id']                                         # 获取session里的id
    order_list = OrderInfo.objects.filter(userinfo_id=user_id).order_by('-oid')  # 查找此用户的订单，并按照id倒序
    paginator = Paginator(order_list, 2)                                         # 获取分页对象，每页显示两条

    page = paginator.page(int(1))

    context = {
        'title': '用户中心',
        'user': user,
        'page_name': 1,
        'paginator': paginator,
        'page': page,
    }
    return render(request, 'user/user_center_order.html', context)
