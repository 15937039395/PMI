from django.conf.urls import include, url
from . import views

urlpatterns = [
    #注册配置
    url(r'^register/$', views.register,name='register'),
    url(r'^register_handel/$', views.register_handel,name='register_handel'),
    #检查用户名
    url(r'^check_name/$', views.check_name,name='check_name'),
    #登录配置
    url(r'^login/$', views.login, name='login'),
    url(r'^login_handel/$', views.login_handel, name='login_handel'),
    #退出登录
    url(r'^logout/$', views.logout, name='logout'),
    url(r'^info/$', views.info, name='info'),
    url(r'^site/$', views.site, name='site'),
    url(r'^user_center_order/$', views.user_center_order, name='user_center_order'),



]
