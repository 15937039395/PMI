from __future__ import unicode_literals
from django.db import models

class UserInfo(models.Model):
    uname = models.CharField(max_length=20,unique=True)          #用户名
    upwd = models.CharField(max_length=100)                      #密码
    uemail = models.CharField(max_length=100)                    #邮箱
    ureceive = models.CharField(max_length=100,default='')       #收货人名
    uaddress = models.CharField(max_length=100, default='')      #收货地址
    uzipcode = models.CharField(max_length=100, default='')      #邮政编码
    uphone = models.CharField(max_length=100, default='')        #联系电话

