# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('user', '0001_initial'),
        ('goods', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='CartInfo',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True, auto_created=True, verbose_name='ID')),
                ('count', models.IntegerField()),
                ('isdelete', models.BooleanField(default=False)),
                ('goodsinfo', models.ForeignKey(to='goods.GoodsInfo')),
                ('userinfo', models.ForeignKey(to='user.UserInfo')),
            ],
        ),
    ]
