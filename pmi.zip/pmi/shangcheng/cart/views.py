from django.shortcuts import render,redirect
from user import user_decorator
from .models import *
from django.http import JsonResponse
from goods.views import cart_count


@user_decorator.login                                        #如果未登录，让用户去登录
def cart(request):
    '''获取当前用户下所有的购物车信息'''
    uid=request.session['user_id']                           #获取session里用户的id
    carts=CartInfo.objects.filter(userinfo_id=uid)           #根据用户的id获取当前用户下所有的购物车的信息
    context = {
        'title': '购物车',
        'page_name': 1,
        'carts': carts,
    }
    return render(request,'cart/cart.html', context)

@user_decorator.login
def add(request,gid,count):                                  #如果未登录，让用户去登录
    '''
    新增
    :param request:
    :param gid:      商品id
    :param count:    商品数量
    :return:
    '''
    uid=request.session['user_id']                           #获取session用户里的id
    gid=int(gid)                                             #获取商品id
    count=int(count)                                         #获取购买数量

    carts=CartInfo.objects.filter(userinfo_id=uid,goodsinfo_id=gid)   #查询购物车中是否有此商品，如果有则数量增加，如果没有则新增
    if len(carts)>=1:
        cart=carts[0]
        cart.count=cart.count+count
    else:
        cart=CartInfo()
        cart.userinfo_id=uid
        cart.goodsinfo_id=gid
        cart.count=count
    cart.save()

    if request.is_ajax():                                     #如果是ajax请求则返回json，否则转向
        count = cart_count(request)                           #获取数量
        return JsonResponse({'count':count})                  #返回json
    else:
        return redirect('/cart/')                                 #重定向到显示



@user_decorator.login
def edit(request,cart_id,count):
    '''
    修改
    :param request:
    :param cart_id:
    :param count:
    :return:
    '''

    count1=1                                                 #存储数量，默认是1
    try:
        cart=CartInfo.objects.get(pk=int(cart_id))           #根据id获取购物车对象
        count1=cart.count
        cart.count=int(count)
        cart.save()                                          #修改
        data={'flag':1}                                      #响应给前端的数据
    except Exception as e:
        data={'flag':count1}
    return JsonResponse(data)


@user_decorator.login
def delete(request,cart_id):
    '''
    根据id删除
    :param request:
    :param cart_id:
    :return:
    '''

    try:
        cart=CartInfo.objects.get(pk=int(cart_id))                          #根据id获取对象
        cart.delete()                                                       #删除
        data={'flag':1}
    except Exception as e:
        data={'flag':0}
    return JsonResponse(data)











