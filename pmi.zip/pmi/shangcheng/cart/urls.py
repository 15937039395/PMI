from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.cart,name='cart'),                       #显示
    url(r'^add/(\d+)/(\d+)/$',views.add,name='add'),          #新增
    url(r'^edit/(\d+)/(\d+)/$',views.edit,name='edit'),       #删除
    url(r'^delete/(\d+)/$',views.delete,name='delete'),       #删除


]
