'''
    出错
    成功
    正在
    大于 2018-1-31 23:59:59 跳过不取
    小于 2018-1-25 0:0:0 结束此循环
'''
import csv
import requests
import time
import datetime
import re
import pandas as pd
from random import uniform
from pymongo import MongoClient

import socket
socket.setdefaulttimeout(5)

try:
    from urllib.parse import quote_plus, urlencode
except:
    from urllib import quote_plus, urlencode

IP = '192.168.0.11'
PORT = '27017'
USERNAME = 'liushizhan'
PASSWORD = 'liushizhan'

class WaimaiComment(object):
    '''
        美团 饿了么 评论数据
    '''
    def __init__(self,DB,startDate=None, dueData='', getExcept=False):
        # 2018-1-31 23:59:59  之间  2018-1-25 0:0:0
        if USERNAME:
            uri = "mongodb://%s:%s@%s:%s" % (
                quote_plus(USERNAME), quote_plus(PASSWORD), IP, PORT)
        else:
            uri = "mongodb://%s:%s"%(IP, PORT)

        self.client = MongoClient(uri)
        self.db = self.client[DB]
        if DB == 'PMI_Waimai_Meituan':
            self.url = 'http://120.76.205.241:8000/comment/meituanwm'
        elif DB == 'PMI_Waimai_Eleme':
            self.url = 'http://120.76.205.241:8000/comment/ele'
        self.params = {
            'id' : '', # Meituan店铺ID
            'pageToken' : '1', # 翻页值
            'apikey' : 'iyRRRaIDWDou6yiDZqAOL9WU03ijEXJfYVxcfvihYOi8BzYE31FoOLovWgHCbIeg'
        }
        # if startDate is not None:
        #     self.startDate = time.strptime(startDate, '%Y-%m-%d %H:%M:%S')
        # else:
        #     self.startDate = startDate
        # self.dueDate = time.strptime(dueData, '%Y-%m-%d %H:%M:%S')

        self.startTime,self.endTime = self.get_time_interval()

        self.getExcept = getExcept
        # 生成集合名
        tm = time.localtime()
        # 根据当前抓取日期生成集合名称
        self.coll_name = 'comment_%s-%s' % (tm.tm_year, tm.tm_mon)
        # 上次正爬取的url转入错误集合
        cursor = self.db[self.coll_name+'_run'].find()
        for cur in cursor:
            cur['errCode'] = '异常终止'
            self.db[self.coll_name+'_err'].insert(cur)
        cursor.close()

    def get_time_interval(self):
        # 获取时间区间
        year = datetime.datetime.today().year
        month = datetime.datetime.today().month
        ed = (datetime.datetime(year, month, 1) - datetime.timedelta(seconds=1)).timetuple()
        if month == 1:
            year = year - 1
            month = 13
        st = datetime.datetime(year, month - 1, 1).timetuple()
        return st,ed

    def get(self, url, params=None, data=None):
        # 清空正在爬取 ,插入当前url
        self.db[self.coll_name+'_run'].remove()

        if params:
            self.db[self.coll_name+'_run'].insert({'url': url + '?' + urlencode(self.params), 'insertTime': time.strftime('%Y-%m-%d %H:%M:%S'),'data': data})
        else:
            self.db[self.coll_name+'_run'].insert({'url': url, 'insertTime': time.strftime('%Y-%m-%d %H:%M:%S'),
                 'data': data})
        try:
            response = requests.get(url=url, params=params, timeout=5)
        except:
            if params:
                self.db[self.coll_name+'_err'].insert({'url': url+'?'+urlencode(params),'errCode':'请求超时','insertTime':time.strftime('%Y-%m-%d %H:%M:%S'), 'data':data})
            else:
                self.db[self.coll_name+'_err'].insert({'url':url,'errCode':'请求超时','insertTime':time.strftime('%Y-%m-%d %H:%M:%S'), 'data':data})
            return False
        return response

    def parse(self, response, data=None):
        if response is False:
            return

        if response.status_code == 200:
            comments = response.json()
            if comments['retcode'] == '000000':
                return comments
            elif comments['retcode'] == '100702' or comments['retcode'] == '100704' or comments['retcode'] == '100701':
                # api维护升级停用,欠费等问题
                self.db[self.coll_name+'_err'].insert({'url': response.url,'errCode':comments['retcode'],'insertTime':time.strftime('%Y-%m-%d %H:%M:%S'),'data':data})
                time.sleep(60*60*2)
            elif comments['retcode'] == '100002':
                self.db[self.coll_name+'_ok'].insert({'url':response.url,'insertTime':time.strftime('%Y-%m-%d %H:%M:%S')})
            else:
                if comments['retcode'] == '100703':
                    time.sleep(0.2)
                for i in range(10):
                    print('\t 尝试重复抓取: ', response.url)
                    comments = self.get(url=response.url).json()
                    if comments['retcode'] == '000000':
                        return comments
                    if i == 9:
                        self.db[self.coll_name+'_err'].insert({'url': response.url, 'errCode': comments['retcode'],'insertTime': time.strftime('%Y-%m-%d %H:%M:%S'),'data':data})
                        return False
        else:
            self.db[self.coll_name+'_err'].insert({'url': response.url, 'insertTime': time.strftime('%Y-%m-%d %H:%M:%S'),'data':data})
            print('错误的响应码:', response.status_code, 'url:', response.url)
            # exit(-1)

    def __call__(self, file):

        df = pd.read_excel(file, sheet_name=None)
        for key in list(df.keys())[:]:
            print('正在处理:', key)
            data = df[key]
            for index in data.index:
                row = [str(each) for each in data.loc[index].values]
                print('正在抓取:', row[3])
                self.params['id'] = row[0]
                if self.params.get('pageToken'):
                    self.params.pop('pageToken')
                cursor = self.db[self.coll_name+'_ok'].find({'url': self.url + '?' + urlencode(self.params)})
                if cursor.count() > 0:
                    print('\t\t此数据已经爬取')
                    cursor.close()
                    continue
                while True:
                    isEnd = False
                    start = time.time()
                    response = self.get(url=self.url, params=self.params, data=row)
                    comments = self.parse(response, row)
                    if comments:
                        # print('\t\t数据写入中...')
                        for comm in comments['data']:
                            # 判断评论开始时间  最近时间  2018-1-31 23:59:59
                            commentTime = time.localtime(comm['publishDate'])
                            if commentTime > self.endTime:
                                # 大于开始是时间的评论跳过
                                continue
                            # 判断评论结束时间  最远时间 2018-1-25 0:0:0
                            if commentTime < self.startTime:
                                isEnd = True
                                break
                            if 1 > 2:
                                continue
                            else:
                                comm['province'] = row[1]
                                comm['city'] = row[2]
                                comm['shopName'] = row[3]
                                # comm['address'] = row[4]
                                self.db[self.coll_name+'_comment'].insert(comm)
                        self.db[self.coll_name+'_ok'].insert({'url': response.url, 'insertTime': time.strftime('%Y-%m-%d %H:%M:%S')})
                        if isEnd:
                            break
                        if comments['hasNext']:
                            self.params['pageToken'] = comments['pageToken']
                            print('\t 获取下一页, pageToken:', comments['pageToken'])
                        else:
                            # 如果没有下一页,返回
                            break
                    else:
                        break
                    end = time.time()
                    if end - start < 0.1:
                        time.sleep(0.1)

        self.dealErr()
        self.client.close()
        # 程序结束
        self.db[self.coll_name+'_run'].remove()

    def dealErr(self):
        for i in range(3):
            cursor = self.db[self.coll_name+'_err'].find({},no_cursor_timeout=True)
            if cursor.count() == 0:
                print('\n请求错误URL的处理完毕!')
                break
            print('第%s次处理错误数据'%(i+1))
            for cur in cursor:
                print('\t处理:',cur['data'][3])
                row = cur['data']
                url = re.match(r'(.*?)\?', cur['url']).group(1)
                params = cur['url'][cur['url'].index('?')+1:].split('&')
                while True:
                    isEnd = False
                    response = self.get(url=url + '?' + '&'.join(params), data=row)
                    comments = self.parse(response, row)
                    if comments:
                        # print('\t\t数据写入中...')
                        for comm in comments['data']:
                            commentTime = time.localtime(comm['publishDate'])
                            # 判断评论开始时间  最近时间  2018-1-31 23:59:59
                            if commentTime > self.endTime:
                                continue
                            # 判断评论结束时间  最远时间 2018-1-25 0:0:0
                            if commentTime < self.startTime:
                                isEnd = True
                                break
                            if self.getExcept:
                                # 判断评论ID是否已经存在
                                cursor_id = self.db[self.coll_name+'_comment'].find({'id':comm['id']})
                                if cursor_id.count()>0:
                                    cursor_id.close()
                                    continue

                            comm['province'] = row[1]
                            comm['city'] = row[2]
                            comm['shopName'] = row[3]
                            # comm['address'] = row[4]
                            self.db[self.coll_name+'_comment'].insert(comm)
                        self.db[self.coll_name+'_ok'].insert({'url':response.url,'insertTime':time.strftime('%Y-%m-%d %H:%M:%S')})
                        if isEnd:
                            break
                        if comments['hasNext']:
                            if len(params) == 3:
                                params[-1] = 'pageToken=%s'%comments['pageToken']
                            else:
                                params.append('pageToken=%s'%comments['pageToken'])
                            print('\t 获取下一页, pageToken:',comments['pageToken'])
                        else:
                            # 如果没有下一页,返回
                            break
                    else:
                        break
                    time.sleep(uniform(0.2,0.3))
                self.db[self.coll_name+'_err'].remove({'_id':cur['_id']})

if __name__ == '__main__':
    # PMI_Waimai_Eleme  PMI_Waimai_Meituan
    comm = WaimaiComment(DB='PMI_Waimai_Eleme', getExcept=False)
    comm(file='./Eleme店铺ID/饿了么201803.xlsx')


'''
from requests.packages.urllib3.exceptions import InsecureRequestWarning

from 大众点评爬虫.MongoDB import MyMongoDB

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
'''
