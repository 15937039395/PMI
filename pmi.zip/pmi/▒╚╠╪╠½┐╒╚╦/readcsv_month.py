import csv
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

from MongoDB import MyMongoDB

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
import time
import sys
import datetime
import os
import pinyin

sys.setrecursionlimit(100000000)  # 设置递归深度
MyMongoDB = MyMongoDB("mongodb://pmi:pmiDatabaseAWE@192.168.0.11:27017")
MyMongoDB.conn()
MyMongoDB.selectDB('PMI_Dianping')
server = '120.76.205.241'


def getApiDianPingData(date, shopid,commentCollName,shopInfo, pageToken=0, week=0):
    apiurl = 'https://' + server + '/comment/dianping?type=time&source=phone&apikey=iyRRRaIDWDou6yiDZqAOL9WU03ijEXJfYVxcfvihYOi8BzYE31FoOLovWgHCbIeg&type=time&source=phone&id=' + shopid + '&pageToken=' + str(
        pageToken)
    data = None
    try:
        print('正在访问->评论信息，shopid->%s，pageToken->%s，爬取日期->%s，请求URL->%s' % (shopid, pageToken, date, apiurl))
        data = requests.get(apiurl, params=None, verify=False).json()
    except:  # 如果请求失败
        global requestCount  # 定义全局请求计次
        requestCount += 1  # 请求计次
        if (requestCount > 100):  # 如果请求计次超过100次,换下一页pageToken继续访问
            print('访问失败->访问下一个pageToken')
            time.sleep(1)
            requestCount = 1
            getApiDianPingData(date, shopid,commentCollName,shopInfo, pageToken + 1)
        else:
            print('访问失败->尝试第%d次' % requestCount)
            time.sleep(1)
            getApiDianPingData(date, shopid,commentCollName,shopInfo, pageToken)

    if data:  # 如果data有数据
        _pageToken = None
        _hasNext = False
        _retcode = None
        if 'pageToken' in dict(data).keys():  # 如果data有pageToken字段,下面同理
            _pageToken = data['pageToken']

        if 'hasNext' in dict(data).keys():
            _hasNext = data['hasNext']

        if 'retcode' in dict(data).keys():
            _retcode = data['retcode']

        if _retcode == '100000':  # 判断错误码,下面同理
            print('请求错误->100000->Server internal error->网络错误->服务器内部错误')
            time.sleep(1)
            getApiDianPingData(date, shopid, commentCollName,shopInfo,pageToken, week)

        if _retcode == '100001':
            time.sleep(1)
            print('请求错误->100001->Network error->网络错误->再次尝试')
            getApiDianPingData(date, shopid, commentCollName,shopInfo,pageToken, week)

        if _retcode == '100002':
            time.sleep(1)
            print('请求错误->100002->Search no result->目标参数搜索没结果')
            file.write('大众点评店铺id->%s，无搜索结果' % (shopid) + '\n')
            return

        if _retcode == '100701':
            time.sleep(1)
            print('请求错误->100701->API stopped->您的当前API已停用')
            exit()

        if _retcode == '100702':
            time.sleep(1)
            print('请求错误->100702->Account stopped->您的账户已停用')
            exit()

        if _retcode == '100703':
            time.sleep(1)
            print('请求错误->100703->API rate limit exceeded->网络错误->并发已达上限')
            getApiDianPingData(date, shopid, commentCollName,shopInfo,pageToken, week)

        if _retcode == '000000':  #
            if int(pageToken) <= 0:
                file.write('大众点评店铺id->%s，爬取正常' % (shopid) + '\n')

            if 'data' in dict(data).keys():  # 如果data有pageToken字段,下面同理
                for dianping in data['data']:
                    referId = dianping['referId']
                    id = dianping['id']
                    publishDate = dianping['publishDate']

                    publishDate ="{}-{}".format(time.localtime(publishDate).tm_year, time.localtime(publishDate).tm_mon)
                    requestCount = 1
                    # 不是今年的结束
                    if int(publishDate.split('-')[0]) < int(thisDate.split('-')[0]):
                        return
                    # 月份更小的也结束
                    if int(publishDate.split('-')[1]) < int(thisDate.split('-')[1]):
                        return

                    if publishDate == thisDate:
                        result = MyMongoDB.insertDianping(dianping,commentCollName,shopInfo, date, week)
                        if result == 0:
                            print(
                                '插入到MongoDB->成功，publishDate->%s，referId->%s，id->%s' % (publishDate, referId, id))
                        if result == 1:
                            print(
                                '插入到MongoDB->失败，publishDate->%s，referId->%s，id->%s' % (publishDate, referId, id))
                        if result == 2:
                            print('插入到MongoDB->重复id，publishDate->%s，referId->%s，id->%s' % (
                                publishDate, referId, id))
                    else:
                        global notThisDateInt
                        print("跳出爬取->不是%s月的数据，publishDate->%s" % (thisDate, publishDate))
                        MyMongoDB.setDianpingShopCommetBool(date, shopid, week)


            if _pageToken == None or _hasNext == False:
                print('大众点评店铺id->%s，爬取完毕' % referId)
                return
            else:
                print('开始访问->下一个pageToken')
                getApiDianPingData(date, shopid, commentCollName,shopInfo,_pageToken, week)  # 继续循环getApiData方法

        if _retcode == None and _pageToken == None and _hasNext == False:  # 如果翻页值=null 且 下一页=false
            return  # 返回,进行下一个城市查询

def get_last_month():
    year,month = time.localtime().tm_year, time.localtime().tm_mon
    ed = (datetime.datetime(year, month, 1) - datetime.timedelta(seconds=1)).timetuple()
    return ed.tm_year,ed.tm_mon

thisDate="{}-{}".format(*get_last_month())



# csv_reader = csv.reader(open(r'./点评/本品_点评德克士店铺ID.csv', encoding='utf-8'))
#
# parameter = {'date': '','commentCollName': 'dicos.3', 'week': '1'}
# file = open('readcsv_' + parameter['date'] + '.txt', "w+", encoding='UTF-8')

# thisDate="2018-02"

def runBitSpace(parameter, csv_reader):
    for row in csv_reader:
        requestCount = 0
        shopid =lv1Name=lv2Name=title=None
        if row[0]!=None and 'id' not in row[0]:
            shopid = row[0]
        if row[1] != None and 'lv' not in row[1]:
            lv1Name = row[1]
        if row[2] != None and 'lv' not in row[2]:
            lv2Name = row[2]
        if row[3] != None and 'title' not in row[3]:
            title = row[3]
        if shopid!=None and lv1Name!=None and lv2Name!=None and title!=None:
            shopInfo={'shopid':shopid,'lv1Name':lv1Name,'lv2Name':lv2Name,'title':title}
            date = parameter['date']
            week = parameter['week']
            commentCollName = parameter['commentCollName']
            getApiDianPingData(date, shopid,commentCollName,shopInfo, 0, week)


def main(file_path):
    for csv_file_name in os.listdir(file_path):
        print('正在处理：', os.path.splitext(csv_file_name)[0])
        csv_reader = csv.reader(open(os.path.join(file_path, csv_file_name), encoding='utf-8'))
        coll_name = pinyin.get(csv_file_name.replace('竞品_','')[:2], format="strip", delimiter="")

        parameter = {'date': '', 'commentCollName': '%s.%s' % (coll_name, time.localtime().tm_mon), 'week': '1'}
        global file
        file = open('readcsv_' + parameter['date'] + '.txt', "w+", encoding='UTF-8')
        runBitSpace(parameter, csv_reader)
        file.close()

if __name__ == '__main__':
    main(r'D:\project\比特太空人\点评竞品')
