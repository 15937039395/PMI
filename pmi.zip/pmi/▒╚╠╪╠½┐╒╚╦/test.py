import csv
import requests
import time
import re
from random import uniform
from pymongo import MongoClient

try:
    from urllib.parse import quote_plus, urlencode
except:
    from urllib import quote_plus, urlencode

IP = 'localhost'
PORT = '27017'
USERNAME = ''
PASSWORD = ''

DB = 'Eleme'

class MeituanComment(object):

    def __init__(self,startDate=None, dueData='2018-1-1 0:0:0'):
        if USERNAME:
            uri = "mongodb://%s:%s@%s:%s" % (
                quote_plus(USERNAME), quote_plus(PASSWORD), IP, PORT)
        else:
            uri = "mongodb://%s:%s"%(IP, PORT)

        self.client = MongoClient(uri)
        self.db = self.client[DB]
        self.url = 'http://120.76.205.241:8000/comment/meituanwm'
        self.params = {
            'id' : '', # Meituan店铺ID
            'pageToken' : '1', # 翻页值
            'apikey' : 'iyRRRaIDWDou6yiDZqAOL9WU03ijEXJfYVxcfvihYOi8BzYE31FoOLovWgHCbIeg'
        }
        if startDate is not None:
            self.startDate = time.strptime(startDate, '%Y-%m-%d %H:%M:%S')
        else:
            self.startDate = startDate
        self.dueDate = time.strptime(dueData, '%Y-%m-%d %H:%M:%S')

    def get(self, url, params=None, data=None):
        try:
            response = requests.get(url=url, params=params, timeout=5)
        except:
            self.db['err'].insert({'url': url+'?'+urlencode(params),'errCode':'请求超时','insertTime':time.strftime('%Y-%m-%d %H:%M:%S'), 'data':data})
            return False
        return response

    def parse(self, response, data=None):
        if response is False:
            return

        if response.status_code == 200:
            comments = response.json()
            if comments['retcode'] == '000000':
                return comments
            elif comments['retcode'] == '100702' or comments['retcode'] == '100704' or comments['retcode'] == '100701':
                # api维护升级停用,欠费等问题
                self.db['err'].insert({'url': response.url,'errCode':comments['retcode'],'insertTime':time.strftime('%Y-%m-%d %H:%M:%S'),'data':data})
                time.sleep(60*60*2)
            elif comments['retcode'] == '100002':
                self.db['OK'].insert({'url':response.url,'insertTime':time.strftime('%Y-%m-%d %H:%M:%S')})
            else:
                for i in range(10):
                    print('\t 尝试重复抓取: ', response.url)
                    comments = self.get(url=response.url).json()
                    if comments['retcode'] == '000000':
                        return comments
                    if i == 9:
                        self.db['err'].insert({'url': response.url, 'errCode': comments['retcode'],'insertTime': time.strftime('%Y-%m-%d %H:%M:%S'),'data':data})
                        return False
        else:
            self.db['err'].insert({'url': response.url, 'insertTime': time.strftime('%Y-%m-%d %H:%M:%S'),'data':data})
            print('错误的响应码:', response.status_code, 'url:', response.url)
            exit(-1)

    def __call__(self, *args, **kwargs):
        with open('./Eleme店铺ID/康师傅私房牛肉面ID_12.csv', 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            for index,row in enumerate(reader):
                if index == 0:
                    continue
                print('正在抓取:',row[3])
                self.params['id'] = row[0]
                if self.params.get('pageToken'):
                    self.params.pop('pageToken')
                cursor = self.db['OK'].find({'url':self.url+'?'+urlencode(self.params)})
                if cursor.count() > 0:
                    print('\t\t此数据已经爬取')
                    continue
                while True:
                    isEnd = False
                    response = self.get(url=self.url, params=self.params,data=row)
                    comments = self.parse(response, row)
                    if comments:
                        print('\t\t数据写入中...')
                        for comm in comments['data']:
                            # 判断评论ID是否已经存在
                            cursor = self.db['comment'].find({'id':comm['id']})
                            if cursor.count()>0:
                                continue
                            else:
                                # 判断评论开始时间
                                if self.startDate is not None and time.strptime(time.ctime(comm['publishDate'])) > self.startDate:
                                    # 最近时间
                                    continue
                                # 判断评论结束时间 最远时间
                                if time.strptime(time.ctime(comm['publishDate'])) < self.dueDate:
                                    isEnd = True
                                    break
                                    pass
                                comm['province'] = row[1]
                                comm['city'] = row[2]
                                comm['shopName'] = row[3]
                                comm['address'] = row[4]
                                self.db['comment'].insert(comm)
                        self.db['OK'].insert({'url':response.url,'insertTime':time.strftime('%Y-%m-%d %H:%M:%S')})
                        if isEnd:
                            break
                        if comments['hasNext']:
                            self.params['pageToken'] = comments['pageToken']
                            print('\t 获取下一页, pageToken:',comments['pageToken'])
                        else:
                            # 如果没有下一页,返回
                            break
                    else:
                        break
                    time.sleep(uniform(0.2,0.3))
        self.dealErr()
        self.client.close()

    def dealErr(self):
        for i in range(3):
            cursor = self.db['err'].find({})
            if cursor.count() == 0:
                print('错误URL处理完毕!')
                break
            print('第%s次处理错误数据'%(i+1))
            for cur in cursor:
                print('\t处理:',cur['data'][3])
                row = cur['data']
                url = re.match(r'(.*?)\?', cur['url']).group(1)
                params = cur['url'][cur['url'].index('?')+1:].split('&')
                while True:
                    isEnd = False
                    response = self.get(url=url + '?' + '&'.join(params), data=row)
                    comments = self.parse(response, row)
                    if comments:
                        print('\t\t数据写入中...')
                        for comm in comments['data']:
                            # 判断评论ID是否已经存在
                            cursor_id = self.db['comment'].find({'id':comm['id']})
                            if cursor_id.count()>0:
                                continue
                            else:
                                # 判断评论时间
                                if time.strptime(time.ctime(comm['publishDate'])) < self.dueDate:
                                    isEnd = True
                                    break
                                    pass
                                comm['province'] = row[1]
                                comm['city'] = row[2]
                                comm['shopName'] = row[3]
                                comm['address'] = row[4]
                                self.db['comment'].insert(comm)
                        self.db['OK'].insert({'url':response.url,'insertTime':time.strftime('%Y-%m-%d %H:%M:%S')})
                        if isEnd:
                            break
                        if comments['hasNext']:
                            if len(params) == 3:
                                params[-1] = 'pageToken=%s'%comments['pageToken']
                            else:
                                params.append('pageToken=%s'%comments['pageToken'])
                            print('\t 获取下一页, pageToken:',comments['pageToken'])
                        else:
                            # 如果没有下一页,返回
                            break
                    else:
                        break
                    time.sleep(uniform(0.2,0.3))
                self.db['err'].remove({'_id':cur['_id']})

if __name__ == '__main__':
    MeituanComment()()


'''
from requests.packages.urllib3.exceptions import InsecureRequestWarning

from 大众点评爬虫.MongoDB import MyMongoDB

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
'''
