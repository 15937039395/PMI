#!/bin/sh
/usr/local/bin/python3.6 /home/script/bigfour/4Platforms/BitSpace/bit_space.py -query Yhd -pre_collection PreYhdCate -dst_collection Yhd -platform yhd -kind product --range 0,10
