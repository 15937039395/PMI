#!/bin/sh
/usr/local/bin/python3.6 /home/script/bigfour/4Platforms/BitSpace/bit_space.py -query Tmall -pre_collection PreTmallCate -dst_collection Tmall -platform tmall -kind product --range 0,10
