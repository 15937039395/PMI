
#!/bin/sh
nowDate=`date "+%Y-%m-%d"`
echo 123$nowDate123
