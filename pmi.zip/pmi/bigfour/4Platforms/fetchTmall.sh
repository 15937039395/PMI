#!/bin/bash

/home/script/bigfour/4Platforms/fetchBase.sh Tmall
