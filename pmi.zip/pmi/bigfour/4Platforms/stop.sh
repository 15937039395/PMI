#!/bin/sh
runBitSpaceAry=('runBitSpace_JD' 'runBitSpace_Taobao' 'runBitSpace_Tmall' 'runBitSpace_Yhd' 'python3.5' )
for((i=0;i<${#runBitSpaceAry[@]};i++))
do
{

#查找脚本进程是否存在,存在则kill
PROCESS=`ps -ef|grep ${runBitSpaceAry[i]}.sh|grep -v grep|grep -v PPID|awk '{ print $2}'`
for j in $PROCESS
do
echo "Kill the process [ $j ] ${runBitSpaceAry[i]}"
kill -9 $j  &>/dev/null
done
     
} 
done
