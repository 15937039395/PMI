#!/bin/sh
/usr/local/bin/python3.6 /home/script/bigfour/4Platforms/BitSpace/bit_space.py -query JD -pre_collection PreJDCate -dst_collection JD -platform jd -kind product --range 0,10
