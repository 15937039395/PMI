# coding: UTF-8

import argparse

from Utility import mongo, common, log, config


def get_log_info(query_str):
	log.tag(__name__).info("Start query log")
	data_filter = {
		"query": query_str
	}
	doc = db_handler_log.find(log_db, log_collection, data_filter, False)
	if doc is None:
		index = -1
		page = -1
		total = -1
	else:
		index = doc.get("th")
		page = doc.get("page")
		total = doc.get("total")
	log.tag(__name__).info("Finish query log")
	return index, page, total


def set_log_info(log_type=None, log_title=None, log_id=None, log_th=-1, log_page=-1, log_total=-1, log_query=None):
	"""
	To setting
	:param log_type:
	:param log_title:
	:param log_id:
	:param log_th:
	:param log_page:
	:param log_total:
	:param log_query:
	:return:
	"""
	g_doc = {
		"appCode": log_type,
		"title": log_title,
		"id": log_id,
		"th": log_th,
		"page": log_page,
		"total": log_total,
		"query": log_query
	}
	db_handler_log.insert_one(log_db, log_collection, g_doc, ["query"])


def get_index(query):
	doc = db_handler_log.find("HenryTest", "IndexLog", {"query": query}, False)
	if doc is None:
		index = 0
	else:
		index = doc["th"]

	return index


def set_index(query, name, shop_id, th):
	doc = {
		"th": th,
		"title": name,
		"shopId": shop_id,
		"query": query
	}
	db_handler_log.insert_one("HenryTest", "IndexLog", doc, ["query"])


def main():

	log.tag(__name__).info("start main")
	data_filter = {
		"isShutdown": {
			"$ne": 1
		},
		"country": "中国",
		"bigCate": "美食",
		"commentCount": {
			"$gte": 0
		}
	}
	index = get_index(g_query_str)
	log.tag(__name__).info("index: %d", index)
	log.tag(__name__).info("start search Dianping")
	source_cursor = db_handler_source.get_cursor(source_db, source_collection, data_filter).sort("_id")
	log.tag(__name__).info("finish search Dianping")
	count = 0
	while True:
		if not source_cursor.alive:
			break
		count += 1
		log.tag(__name__).info("%d th", count)
		if count < index:
			continue
		index = -1
		result = source_cursor.next()
		log.tag(__name__).info("shopId: %s", result.get("shopId"))
		doc = {
			"th": count,
			"shopId": result.get("shopId"),
			"name": result.get("name"),
			"commentCount": result.get("commentCount")
		}
		db_handler_destination.insert_one(destination_db, destination_collection, doc, ["shopId"])
		set_index(query=g_query_str, name=result.get("name"), shop_id=result.get("shopId"), th=count)
	source_cursor.close()
	log.tag(__name__).info("finish main")


if __name__ == '__main__':
	log.set_level("INFO")
	log.tag(__name__).info("Start export_shopId")
	environment_config = config.ConfigHandler(__file__)
	destination_setting = environment_config.read_configure("environment.ini", "DESTINATION")
	source_setting = environment_config.read_configure("environment.ini", "SOURCE")
	log_setting = environment_config.read_configure("environment.ini", "LOG")

	parser = argparse.ArgumentParser("This is tool that extract the data of bitspace api and version is 0.0.4")
	parser.set_defaults(func=main)
	parser.add_argument("-query", action="store", type=str, help="please input query for TransLog", default="")
	parser.add_argument("--sort", action="store", type=str, help="please input sort key for source collection query",
	                    default=None)
	parser.add_argument("-src_collection", action="store", type=str, help="please input the source collection",
	                    default="")
	parser.add_argument("-dst_collection", action="store", type=str, help="please input the destination collection",
	                    default="")
	args = parser.parse_args()
	log_ip = log_setting["ip"]
	log_db = log_setting["db"]
	log_collection = log_setting["collection"]
	log_auth = log_setting["auth"]
	source_ip = source_setting["ip"]
	source_db = source_setting["db"]
	source_auth = log_setting["auth"]
	source_collection = args.src_collection
	destination_ip = destination_setting["ip"]
	destination_db = destination_setting["db"]
	destination_auth = destination_setting["auth"]
	destination_collection = args.dst_collection
	g_query_str = args.query
	if args.sort is not None:
		g_sort_key = args.sort
	g_page_size = 10000
	log.tag(__name__).info("log ip: " + log_ip)
	log.tag(__name__).info("log db: " + log_db)
	log.tag(__name__).info("log collection: " + log_collection)
	log.tag(__name__).info("log auth: " + log_auth)
	log.tag(__name__).info("log query: " + g_query_str)
	log.tag(__name__).info("source ip: " + source_ip)
	log.tag(__name__).info("source db: " + source_db)
	log.tag(__name__).info("source collection: " + source_collection)
	log.tag(__name__).info("source auth: " + source_auth)
	log.tag(__name__).info("source sort key:" + g_sort_key)

	log.tag(__name__).info("destination ip: " + destination_ip)
	log.tag(__name__).info("destination db: " + destination_db)
	log.tag(__name__).info("destination collection: " + destination_collection)
	log.tag(__name__).info("destination auth: " + destination_auth)

	db_handler_log = mongo.MongoHandler(log_ip, auth="0")
	db_handler_source = mongo.MongoHandler(source_ip, auth="0")
	db_handler_destination = mongo.MongoHandler(destination_ip, auth="0")

	main()

	db_handler_log.close_disconnect()
	db_handler_source.close_disconnect()

	log.tag(__name__).info("Finish export_shopId")
