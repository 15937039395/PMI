# coding:UTF-8

import time
import datetime
import argparse
import ast
import pprint
import json

from urllib import parse

from utility import common, config, mongo
from utility.crawler_logger import init_logger

key = "iyRRRaIDWDou6yiDZqAOL9WU03ijEXJfYVxcfvihYOi8BzYE31FoOLovWgHCbIeg"
#
root_url_a = "http://api01.bitspaceman.com:8000/"
#
root_url_b = "http://api02.bitspaceman.com:8000/"
#
root_url_c = "http://123.206.51.176:8000/"

web_shop_cate = ["jd", "yhd", "taobao", "tmall"]

waimai_platform_cate = ["ele", "baiduwaimai", "meituanwm"]

PLATFORM = "platform"
KIND = "kind"

RESTAURANT = "restaurant"
SHOPPING = "shopping"
COMMENT = "comment"
PRODUCT = "product"


DIANPING = "dianping"

RAWVERSION = "RawVersion"


conditionDateTime = datetime.datetime(2016, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)


def delete_log(query_key):
	query = {
		"query": query_key
	}
	db_handler_log.delete("HenryTest", "BitSpaceLog", query, False)

	query_filter = {
		"key": query_key
	}
	db_handler_log.delete("HenryTest", "APIPageLog", query_filter, True)


def parse_waimai_json(data, collection):
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "parse_waimai_json", collection)
	"""

	:param data:
	:return:
	"""
	# print("parse_waimai_json")
	data["shopId"] = data.pop("id")
	data["shopName"] = data.pop("title")
	data["status"] = 0
	db_handler_dst.insert_one(dst_db, collection, data, ["shopId"])


def parse_waimai_baidu_data(data):
	"""

	:param data:
	:return:
	"""
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "parse_waimai_baidu_data")
	url = "http://api01.bitspaceman.com:8000/product/baiduwaimai"
	parameter_map = {
		"id": data["id"],
		"apikey": key
	}
	print("waimai baidu id:", data["id"])
	query_string = parse.urlencode(parameter_map)
	logger.info("%s %s", url, query_string)
	while True:
		json_data, error_message = common.get_common_api(url=url, query_parameter=query_string,
		                                                 timeout=30)

		if json_data:
			if "data" in json_data:
				for i, result in enumerate(json_data["data"]):
					print(i, "th baidu product")
					db_handler_dst.insert_one("Octavius", "WaimaiBaiduMenu", result, ["id"])
				break
			elif "message" in json_data:
				real_url = url + "?" + query_string
				if json_data["message"] == "search no result":
					logger.info("url: %s search no result", real_url)
					break
				elif json_data["message"] == "Server internal error":
					logger.info("url: %s Server internal error", real_url)
					continue
				else:
					logger.info("url: %s  message: %s", real_url, json_data["message"])
					continue
			else:
				logger.info("other error: " + str(json_data))
				continue

		else:
			print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "error message", error_message)
			error_map = {
				"shopId": data["id"],
				"key": g_query,
				"platform": g_platform,
				"kind": g_kind,
				"errorMessage": error_message
			}
			db_handler_log.insert_one(log_db, error_collection, error_map,
			                          ["key", "shopId", "platform", "kind", "errorMessage"])
			continue

	data["shopId"] = data.pop("id")
	data["shopName"] = data.pop("title")
	data["status"] = 0
	db_handler_dst.insert_one("Octavius", dst_collection, data, ["shopId"])


def parse_ele_data(data):
	"""

	:param data:
	:return:
	"""
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "parse_ele_data")

	products = data.pop("products")
	menu_collection = dst_collection + "_" + g_version
	collection = "Eleme_" + g_version
	print("insert ", menu_collection)
	for i, product in enumerate(products):
		print(i, "th product")
		db_handler_dst.insert_one("Octavius", menu_collection, product, ["id"])

	print("insert ", collection)
	data["shopId"] = data.pop("id")
	data["shopName"] = data.pop("title")
	data["status"] = 0
	db_handler_dst.insert_one("Octavius", collection, data, ["shopId"])


def parse_web_shop_json(data, collection, major_tag, category):
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "parse_web_shop_json")
	"""

	:param data:
	:param collection:
	:param major_tag:
	:param category:
	:return:
	"""
	data["majorTag"] = major_tag
	data["category"] = category

	db_handler_dst.insert_one(dst_db, collection, data, ["id"])


def parse_tmall_product(data, collection, major_tag, category):
	"""
	
	:param data:
	:param collection:
	:param major_tag:
	:param category:
	:return:
	"""
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "parse_tmall_product")
	url = root_url_b + g_kind + "/" + g_platform
	parameter_map = {
		"apikey": key,
		"id": data.get("id")
	}
	query_string = parse.urlencode(parameter_map)
	logger.info("%s %s", url, query_string)
	while True:
		json_data, error_message = common.get_common_api(url=url, query_parameter=query_string, timeout=60)
		if json_data is not None:
			if "data" in json_data:
				doc = json_data.get("data")[0]
				doc["majorTag"] = major_tag
				doc["category"] = category
				db_handler_dst.insert_one(dst_db, collection, doc, ["id"])
			elif "message" in json_data:
				real_url = url + "?" + query_string
				if json_data["message"] == "search no result":
					logger.info("url: %s search no result", real_url)
					break
				elif json_data["message"] == "Server internal error":
					logger.info("url: %s Server internal error", real_url)
					continue
				else:
					logger.info("url: %s  message: %s", url, json_data["message"])
					continue
			break
		else:
			print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "error message", error_message)
			error_map = {
				"id": data["id"],
				"key": g_query,
				"platform": g_platform,
				"kind": g_kind,
				"errorMessage": error_message
			}
			db_handler_log.insert_one(log_db, error_collection, error_map,
									  ["key", "id", "platform", "kind", "errorMessage"])
			time.sleep(0.125)
			continue
			

def parse_taobao_product(data, collection, major_tag, category):
	"""
	
	:param data:
	:param collection:
	:param major_tag:
	:param category:
	:return:
	"""
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "parse_taobao_product")
	url = root_url_b + g_kind + "/" + g_platform
	parameter_map = {
		"apikey": key,
		"type": "product",
		"id": data.get("id")
	}
	query_string = parse.urlencode(parameter_map)
	logger.info("%s %s", url, query_string)
	while True:
		json_data, error_message = common.get_common_api(url=url, query_parameter=query_string, timeout=60)
		if json_data is not None:
			if "data" in json_data:
				doc = json_data.get("data")[0]
				doc["majorTag"] = major_tag
				doc["category"] = category
				db_handler_dst.insert_one(dst_db, collection, doc, ["id"])
			elif "message" in json_data:
				real_url = url + "?" + query_string
				if json_data["message"] == "search no result":
					logger.info("url: %s search no result", real_url)
					break
				elif json_data["message"] == "Server internal error":
					logger.info("url: %s Server internal error", real_url)
					continue
				else:
					logger.info("url: %s  message: %s", url, json_data["message"])
					continue
			break
		else:
			print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "error message", error_message)
			error_map = {
				"id": data["id"],
				"key": g_query,
				"platform": g_platform,
				"kind": g_kind,
				"errorMessage": error_message
			}
			db_handler_log.insert_one(log_db, error_collection, error_map,
									  ["key", "id", "platform", "kind", "errorMessage"])
			time.sleep(0.125)
			continue
	

def parse_dianping_shopping_joson(data):
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "parse_dianping_shopping_joson")
	url = "http://api01.bitspaceman.com:8000/shopping/dianping"
	cover_url = data["coverUrl"]
	parameter_map = {
		"id": data["id"],
		"apikey": key
	}
	query_string = parse.urlencode(parameter_map)
	logger.info("%s %s", url, query_string)
	while True:
		json_data, error_message = common.get_common_api(url=url, query_parameter=query_string,
		                                                 timeout=30)
		if json_data:
			if "data" in json_data:
				# pprint.pprint(json_data)
				for i, result in enumerate(json_data["data"]):
					# pprint.pprint(result)
					result["shopId"] = result.pop("id")
					result["name"] = result.pop("title")
					result["shopStar"] = result.pop("rating")
					result["productRating"] = result.pop("qualRating")
					result["serviceRating"] = result.pop("servRating")
					result["environmentRating"] = result.pop("enviRating")
					result["thinkGood"] = result.pop("goodTagDist")
					result["thinkBad"] = result.pop("badTagDist")
					result["bigCate"] = result.pop("catName1")
					result["smallCate"] = result.pop("catName2")
					result["coverUrl"] = cover_url
					print(result["shopId"])
					db_handler_dst.insert_one("Octavius", dst_collection, result, ["shopId"])
				break
			elif "message" in json_data:
				url = url + "?" + query_string
				if json_data["message"] == "search no result":
					logger.info("url: %s search no result", url)
					break
				elif json_data["message"] == "Server internal error":
					logger.info("url: %s Server internal error", url)
					continue
				else:
					logger.info("url: %s  message: %s", url, json_data["message"])
					continue
			else:
				logger.info("other error: " + str(json_data))
				continue
		else:
			print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "error message", error_message)
			error_map = {
				"shopId": data["id"],
				"key": g_query,
				"platform": g_platform,
				"kind": g_kind,
				"errorMessage": error_message
			}
			db_handler_log.insert_one(log_db, error_collection, error_map,
			                          ["key", "shopId", "platform", "kind", "errorMessage"])
			continue


def parse_dianping_json(data, collection, page):
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "parse_dianping_json")
	
	query = {
		"shopId": data.get("id")
	}
	result = db_handler_dst.find(dst_db, collection+"Log", query, False)
	if result is None:
		doc = {
			"shopId": data.get("id"),
			"pageToke": [page],
		}
		db_handler_dst.insert_one(dst_db, collection+"Log", doc, ["shopId"])
	else:
		print("this shop id has existed")
		result.get("pageToke").append(page)
		db_handler_dst.insert_one(dst_db, collection+"Log", result, ["shopId"])

	data["shopId"] = data.pop("id")
	data["name"] = data.pop("title")
	data["shopStar"] = data.pop("rating")
	data["productRating"] = data.pop("qualRating", None)
	data["serviceRating"] = data.pop("servRating", None)
	data["environmentRating"] = data.pop("enviRating", None)
	data["thinkGood"] = data.pop("goodTagDist", None)
	data["thinkBad"] = data.pop("badTagDist", None)
	data["bigCate"] = data.pop("catName1")
	data["smallCate"] = data.pop("catName2")
	data["status"] = 0
	print(data["shopId"])
	db_handler_dst.insert_one(dst_db, collection, data, ["shopId"])


def parse_dianping_comment_json(data):
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "parse_dianping_comment_json")
	data_map = {
		"commentId": data["id"],
		"shopId": data["referId"],
		"content": data["content"],
		"publishDate": datetime.datetime.fromtimestamp(data["publishDate"], datetime.timezone.utc),
		"commentStars": data["rating"],
		"tags": data["tags"],
		"publisher": data["commenterScreenName"],
		"publisherId": data["commenterId"],
		"likeCount": data["likeCount"],
		"commentCount": data["commentCount"],
		"imageUrls": data["imageUrls"],
		"source": data["source"]
	}
	if "viewCount" in data:
		data_map["viewCount"] = data["viewCount"]
	if "commenterIdGrade" in data:
		data_map["publisherRank"] = data["commenterIdGrade"]

	db_handler_dst.insert_one(dst_db, dst_collection, data_map, ["commentId"])


def parse_web_shop_comment(data):
	"""

	:param data:
	:return:
	"""
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "parse_web_shop_comment")
	data["commentId"] = data.pop("id")
	data["commenter"] = data.pop("commenterScreenName")
	data["publishDate"] = datetime.datetime.fromtimestamp(data.pop("publishDate"), datetime.timezone.utc)
	db_handler_dst.insert_one(dst_db, dst_collection, data, ["commentId"])


def get_log(collection, query):
	log_data = db_handler_log.find(log_db, collection, {"query": query}, False)
	if log_data is None:
		index = -1
		total = -1
		page = -1
	else:
		index = log_data["th"]
		total = log_data["total"]
		page = log_data["page"]
	return index, total, page


def bit_space_api(**kwargs):
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "start bit_space_api")

	platform = kwargs["platform"]
	kind = kwargs["kind"]
	shop_id = ""
	longitude = ""
	latitude = ""
	cat_id = ""
	kw = ""
	major_tag = ""
	city_id = ""
	seller_id = ""
	if "shop_id" in kwargs:
		shop_id = kwargs["shop_id"]
	if "longitude" in kwargs:
		longitude = kwargs["longitude"]
	if "latitude" in kwargs:
		latitude = kwargs["latitude"]
	if "cat_id" in kwargs:
		cat_id = kwargs["cat_id"]
	if "kw" in kwargs:
		kw = kwargs["kw"]
	if "major_tag" in kwargs:
		major_tag = kwargs["major_tag"]
	if "category" in kwargs:
		category = kwargs["category"]
	if "city_id" in kwargs:
		city_id = kwargs["city_id"]
	if "product_id" in kwargs:
		product_id = kwargs["product_id"]
	if "seller_id" in kwargs:
		seller_id = kwargs["seller_id"]
	if "func" in kwargs:
		func = kwargs["func"]
	if "search_type" in kwargs:
		search_type = kwargs["search_type"]

	#切換比特太空人區域
	if platform == "tmall" or platform == "taobao":
		platform_kind_url = root_url_b + kind + "/" + platform
	else:
		platform_kind_url = root_url_a + kind + "/" + platform

	# calculate the count of API by using
	count_log = db_handler_log.find(log_db, "APILog", {"url": platform_kind_url, "key": g_query}, False)
	if count_log is None:
		count = 0
	else:
		count = count_log["count"]

	# get the page number of this API
	# 四大電商的商品
	data_filter = {
		"key": g_query,
	}
	if kind == "product":
		if platform in web_shop_cate:
			if cat_id is None:
				data_filter["kw"] = kw
			else:
				data_filter["catId"] = cat_id
	# 餐館
	elif kind == "restaurant":
		# 三大外賣
		if platform in waimai_platform_cate:
			data_filter["lon"] = longitude
			data_filter["lat"] = latitude
		# 大眾點評
		elif platform == "dianping":
			data_filter["cityId"] = city_id
	elif kind == "shopping":
		if platform == "dianping":
			data_filter["cityId"] = city_id
	# 其他 如三大外賣的菜單和大眾點評的評論
	elif kind == "comment":
		data_filter["id"] = shop_id
	elif kind == "product":
		data_filter["id"] = shop_id
	else:
		logger.info("no match any kind")
		return

	api_page_log = db_handler_log.find(log_db, "APIPageLog", data_filter, False)
	if api_page_log is None:
		page = 0
	else:
		page = api_page_log["page"]

	while True:
		print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", page, "page data")
		parameter_map = {
			"apikey": key,
			"pageToken": page
		}
		# 菜單或商品
		if kind == "product":
			# 四大電商 商品的api parameter
			if platform in web_shop_cate:
				if cat_id is None:
					parameter_map["kw"] = kw
				else:
					parameter_map["catid"] = cat_id
				if search_type:
					parameter_map["searchType"] = search_type
			# 三大外賣的 菜品的api parameter
			elif platform in waimai_platform_cate:
				parameter_map["id"] = shop_id
		# 餐館
		elif kind == "restaurant":
			# 三大外賣 餐館的api parameter
			if platform in waimai_platform_cate:
				# 針對餓了嗎 抓取菜單
				if "Menu" in g_query:
					parameter_map["id"] = shop_id
				else:
					parameter_map["lon"] = longitude
					parameter_map["lat"] = latitude
			# 大眾點評 餐館的api parameter
			elif platform == "dianping":
				cat_id = "10"
				parameter_map["cityid"] = city_id
				parameter_map["catid"] = cat_id
		elif kind == "shopping":
			if platform == "dianping":
				cat_id = "20"
				parameter_map["cityid"] = city_id
				parameter_map["catid"] = cat_id
				if g_kw:
					parameter_map["kw"] = g_kw
		# 評論
		elif kind == "comment":
			# 大眾點評 評論的api parameter
			if platform == "dianping" or platform in web_shop_cate:
				parameter_map["id"] = shop_id
				parameter_map["type"] = "time"
			if platform in web_shop_cate:
				if platform == "taobao" or platform == "tmall":
					parameter_map["id"] = product_id
					parameter_map["uid"] = seller_id
				elif platform == "yhd":
					parameter_map["id"] = product_id
				elif platform == "jd":
					parameter_map["id"] = product_id
					parameter_map["sortType"] = "6"
					parameter_map["level"] = "0"

		query_string = parse.urlencode(parameter_map)
		logger.info("%s %s", platform_kind_url, query_string)
		json_data, error_message = common.get_common_api(url=platform_kind_url, query_parameter=query_string,
		                                                 timeout=60)
		if json_data is not None:
			# print(json_data, error_message)
			if "data" in json_data:
				count += 1
				call_api_map = {
					"url": platform_kind_url,
					"key":  g_query,
					"count": count,
				}
				db_handler_log.insert_one(log_db, "APILog", call_api_map, ["url", "key"])
				results = json_data["data"]
				# pprint.pprint(results)
				for i, result in enumerate(results):
					print(i, "th result")
					collection = dst_collection
					if kind == "product":
						result["version"] = g_version
						if platform == "jd":
							parse_web_shop_json(result, collection, major_tag, category)
						elif platform == "yhd":
							parse_web_shop_json(result, collection, major_tag, category)
						elif platform == "taobao":
							parse_taobao_product(result, collection, major_tag, category)
							time.sleep(0.125)
						elif platform == "tmall":
							parse_tmall_product(result, collection, major_tag, category)
							time.sleep(0.125)
							# parse_web_shop_json(result, collection, major_tag, category)
						elif platform == "ele":
							parse_ele_data(result)
						elif platform == "baiduwaimai":
							db_handler_dst.insert_one(dst_db, collection, result, ["id"])
						elif platform == "meituanwm":
							db_handler_dst.insert_one(dst_db, "WaimaiMeituanMenu", result, ["id"])
					elif kind == "restaurant":
						result["version"] = g_version
						if platform == "ele":
							if "Menu" in g_query:
								parse_ele_data(result)
							else:
								parse_waimai_json(result, collection)
							# parse_ele_data(result)
						elif platform == "baiduwaimai":
							parse_waimai_json(result, collection)
						elif platform == "meituanwm":
							parse_waimai_json(result, "WaimaiMeituan")
						elif platform == "dianping":
							parse_dianping_json(result, collection, page)
					elif kind == "shopping":
						if platform == "dianping":
							parse_dianping_shopping_joson(result)
					elif kind == "comment":
						if platform == "dianping":
							parse_dianping_comment_json(result)
						if platform in web_shop_cate:
							parse_web_shop_comment(result)

				if kind == "product":
					pass
				elif kind == "restaurant":
					pass
				elif kind == "shopping":
					pass
				elif kind == "comment":
					if platform == "dianping":
						# pprint.pprint(result)
						if g_term > datetime.datetime.fromtimestamp(results[-1]["publishDate"], datetime.timezone.utc):
							logger.info(str(shop_id) + " is completed and the last extract " + str(
								datetime.datetime.fromtimestamp(results[-1]["publishDate"], datetime.timezone.utc)))
							break
					elif platform in web_shop_cate:
						print(results[-1]["publishDate"])
						if g_term > results[-1]["publishDate"]:
							logger.info(str(product_id) + " is completed and the last extract " + str(results[-1]["publishDate"]))
							break

			elif "message" in json_data:
				url = platform_kind_url + "?" + query_string
				if json_data["message"] == "search no result":
					logger.info("url: %s search no result", url)
					break
				elif json_data["message"] == "Server internal error":
					logger.info("url: %s Server internal error", url)
					continue
				else:
					logger.info("url: %s  message: %s", url, json_data["message"])
					continue
			else:
				logger.info("other error: " + str(json_data))
				continue

			if "hasNext" in json_data:
				if json_data["hasNext"] is False:
					break
		else:
			# logger.exception(error_message)
			print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "error message", error_message)
			error_map = {
				"shopId": shop_id,
				"key": g_query,
				"platform": platform,
				"kind": kind,
				"page": page,
				"errorMessage": error_message
			}
			error_identifiers = ["kind", "platform", "key", "page", "errorMessage"]
			if kind == "product":
				if platform in web_shop_cate:
					error_map["catId"] = cat_id
					error_identifiers.append("catId")
				elif platform in waimai_platform_cate:
					error_map["id"] = shop_id
					error_identifiers.append("id")
			elif kind == "restaurant":
				if platform == "dianping":
					error_map["cityId"] = city_id
					error_map["catId"] = cat_id
					error_identifiers.append("cityId")
					error_identifiers.append("catId")
				elif platform in waimai_platform_cate:
					error_map["lon"] = longitude
					error_map["lat"] = latitude
					error_identifiers.append("lon")
					error_identifiers.append("lat")
			elif kind == "shopping":
				if platform == "dianping":
					error_map["cityId"] = city_id
					error_map["catId"] = cat_id
					error_identifiers.append("cityId")
					error_identifiers.append("catId")
			elif kind == "comment":
				if platform == "dianping":
					error_map["id"] = shop_id
					error_identifiers.append("id")
				elif platform in web_shop_cate:
					error_map["id"] = product_id
					error_identifiers.append("id")
			db_handler_log.insert_one(log_db, error_collection, error_map, error_identifiers)
			continue

		page += 1
		api_page_log_map = {
			"platform": g_platform,
			"kind": g_kind,
			"key": g_query,
			"page": page
		}
		api_page_identifiers = ["kind", "platform", "key"]
		if kind == "product":
			if platform in web_shop_cate:
				api_page_log_map["catId"] = cat_id
				api_page_identifiers.append("catId")
			elif platform in waimai_platform_cate:
				api_page_log_map["id"] = shop_id
				api_page_identifiers.append("id")
		elif kind == "restaurant":
			if platform in web_shop_cate:
				pass
			elif platform in waimai_platform_cate:
				api_page_log_map["lon"] = longitude
				api_page_log_map["lat"] = latitude
				api_page_identifiers.append("lon")
				api_page_identifiers.append("lat")
			elif platform == "dianping":
				api_page_log_map["cityId"] = city_id
				api_page_identifiers.append("cityId")
		elif kind == "shopping":
			if platform == "dianping":
				api_page_log_map["cityId"] = city_id
				api_page_identifiers.append("cityId")
		elif kind == "comment":
			if platform == "dianping":
				api_page_log_map["id"] = shop_id
				api_page_identifiers.append("id")
			elif platform in web_shop_cate:
				api_page_log_map["id"] = product_id
				api_page_identifiers.append("id")
		db_handler_log.insert_one(log_db, "APIPageLog", api_page_log_map, api_page_identifiers)
		time.sleep(0.125)

	# db_handler_log.delete(log_db, "APILog", delete_filter, False)
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "finish bit_space_api")


def insert_raw_version(status):
	"""
	
	:param status:
	:return:
	"""
	doc = {
		"source": dst_collection,
		"signature": g_version,
	}
	if status is True:
		doc["finishCrawling"] = True
	else:
		doc["finishCrawling"] = False
	
	if "Menu" in dst_collection:
		doc["individual"] = False
	else:
		doc["individual"] = True
	db_handler_dst.insert_one(dst_db, RAWVERSION, doc, ["source", "signature"])
	

def bit_space():
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "start bit_space")
	
	insert_raw_version(False)
	
	index, total, index_page = get_log(log_collection, g_query)
	data_filter = {}
	if (g_kind == "restaurant" or g_kind == "shopping") and g_platform == "dianping":
		if g_search is not None:
			pprint.pprint(g_search)
			data_filter = json.loads(g_search)
			pprint.pprint(data_filter)
		else:
			data_filter = {
				"description": {
					"$regex": "中国",
					"$options": "i"
				}
			}
	elif g_kind == "comment":
		if g_platform in web_shop_cate:
			if g_search is not None:
				pprint.pprint(g_search)
				data_filter = json.loads(g_search)
				pprint.pprint(data_filter)
	elif g_kind == "product":
		if g_platform in web_shop_cate:
			if g_search is not None:
				pprint.pprint(g_search)
				data_filter = json.loads(g_search)
				pprint.pprint(data_filter)

	# print(index, index_page, total)
	if total == -1:
		print(dst_db, pre_collection)
		log_map = {
			"th": -1,
			"page": -1,
			"query": g_query,
			"total": total,
		}
		if (g_kind == "restaurant" or g_kind == "shopping") and g_platform == "dianping":
			total = db_handler_dst.count(dst_db, pre_collection, data_filter)
			log_map["total"] = total
			db_handler_log.insert_one(log_db, log_collection, log_map, ["query"])
		else:
			if g_kind == "product":
				if g_platform in waimai_platform_cate:
					print(pre_collection + "_" + g_version)
					total = db_handler_dst.count(dst_db, pre_collection + "_" + g_version, data_filter)
				else:
					total = db_handler_dst.count(dst_db, pre_collection, data_filter)
			elif g_kind == "comment":
				total = db_handler_dst.count(dst_db, pre_collection, data_filter)
			else:
				total = db_handler_dst.count(dst_db, pre_collection, data_filter)

			log_map["total"] = total
			db_handler_log.insert_one(log_db, log_collection, log_map, ["query"])

	print("total:", total, "results")

	pages = common.set_total_page(total=total, size=g_page_size)
	if g_range is None:
		range_page = range(pages)
	else:
		range_page = range(g_start, g_start + g_num)
	data_projection = {}
	
	if g_kind == "product":
		if g_platform in web_shop_cate:
			data_projection["catId"] = 1
			data_projection["description"] = 1
			data_projection["majorTag"] = 1
			data_projection["kw"] = 1
		# 三大外賣
		else:
			data_projection["shopId"] = 1
			data_projection["shopName"] = 1
	elif g_kind == "restaurant":
		if g_platform in waimai_platform_cate:
			# 針對餓了嗎
			if "Menu" in g_query:
				data_projection["shopId"] = 1
				data_projection["shopName"] = 1
			else:
				data_projection["lon"] = 1
				data_projection["lat"] = 1
		if g_platform == "dianping":
			data_projection["cityId"] = 1
			data_projection["description"] = 1
	elif g_kind == "shopping":
		if g_platform == "dianping":
			data_projection["cityId"] = 1
			data_projection["description"] = 1
	elif g_kind == "comment":
		if g_platform == "dianping":
			data_projection["shopId"] = 1
			data_projection["shopName"] = 1
		elif g_platform in web_shop_cate:
			data_projection["id"] = 1
			data_projection["sellerId"] = 1

	for page_num in range_page:
		print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", page_num, "page document")
		if page_num < index_page:
			continue
		elif page_num == index_page and index == (g_page_size - 1):
			index = -1
			continue
		else:
			print(dst_db, pre_collection, dst_collection)
			if (g_kind == "restaurant" or g_kind == "shopping") and g_platform == "dianping":
				results = db_handler_dst.find_many(dst_db, pre_collection, data_filter, data_projection, page=page_num,
			                                   limit=g_page_size)
			else:
				if g_kind == "product":
					if g_platform in waimai_platform_cate:
						results = db_handler_dst.find_many(dst_db, pre_collection + "_" + g_version, data_filter,
						                                   data_projection, page=page_num, limit=g_page_size)
					else:
						results = db_handler_dst.find_many(dst_db, pre_collection, data_filter, data_projection, page=page_num,
						                                   limit=g_page_size)
				elif g_kind == "comment":
					results = db_handler_dst.find_many(dst_db, pre_collection, data_filter, data_projection,
													   page=page_num, limit=g_page_size)
				else:
					results = db_handler_dst.find_many(dst_db, pre_collection, data_filter, data_projection, page=page_num, limit=g_page_size)
			for i, result in enumerate(results):
				print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", i, "th")
				if i <= index:
					continue
				index = -1
				log_map = {
					"th": i,
					"query": g_query,
					"total": total,
					"page": page_num,
				}
				if g_kind == "product":
					if g_platform in web_shop_cate:
						log_map["catId"] = result.get("catId")
						log_map["kw"] = result.get("description")
						log_map["description"] = result["description"]
						print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", i, "th", result.get("catId"),
						      result["description"])
						bit_space_api(platform=g_platform, kind=g_kind, cat_id=result.get("catId"),
						              kw=result["description"], major_tag=result["majorTag"],
						              category=result["description"], search_type=g_search_type)
					# 三大外賣
					else:
						log_map["id"] = result.get("shopId")
						log_map["shopName"] = result.get("shopName")
						print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", i, "th", result.get("shopId"),
						      result["shopName"])
						bit_space_api(platform=g_platform, kind=g_kind, shop_id=result.get("shopId"))
				elif g_kind == "restaurant":
					if g_platform in waimai_platform_cate:
						# 針對餓了嗎
						if "Menu" in g_query:
							log_map["id"] = result.get("shopId")
							log_map["shopName"] = result.get("shopName")
							print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", i, "th", result["shopId"],
							      result["shopName"])
							bit_space_api(platform=g_platform, kind=g_kind, shop_id=result.get("shopId"))
						else:
							log_map["longitude"] = result["lon"]
							log_map["latitude"] = result["lat"]
							print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", i, "th", result["lon"],
							      result["lat"])
							bit_space_api(platform=g_platform, kind=g_kind, longitude=result["lon"],
							              latitude=result["lat"])
					elif g_platform == "dianping":
						log_map["cityId"] = result["cityId"]
						log_map["description"] = result["description"]
						print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", i, "th", result["cityId"],
						      result["description"])
						bit_space_api(platform=g_platform, kind=g_kind, city_id=result["cityId"])
				elif g_kind == "shopping":
					if g_platform == "dianping":
						log_map["cityId"] = result["cityId"]
						log_map["description"] = result["description"]
						log_map["keyword"] = g_kw
						print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", i, "th", result["cityId"],
						      result["description"], g_kw)
						bit_space_api(platform=g_platform, kind=g_kind, city_id=result["cityId"])
				elif g_kind == "comment":
					if g_platform == "dianping":
						log_map["id"] = result.get("shopId")
						print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", i, "th", result["shopId"])
						bit_space_api(platform=g_platform, kind=g_kind, shop_id=result["shopId"])
					if g_platform in web_shop_cate:
						print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", i, "th", result["id"])
						if g_platform == "taobao" or g_platform == "tmall":
							log_map["productId"] = result.get("id")
							log_map["sellerId"] = result.get("sellerId")
							bit_space_api(platform=g_platform, kind=g_kind, product_id=result["id"],
										  seller_id=result["sellerId"])
						elif g_platform == "yhd":
							log_map["productId"] = result.get("id")
							bit_space_api(platform=g_platform, kind=g_kind, product_id=result["id"])
						elif g_platform == "jd":
							log_map["productId"] = result.get("id")
							bit_space_api(platform=g_platform, kind=g_kind, product_id=result["id"])
						
				db_handler_log.insert_one(log_db, log_collection, log_map, ["query"])
	# db_handler_log.find()
	# check all Crawler
	query = {
		"query": {
			"$regex": g_platform + "_" + g_kind
		}
	}
	results = db_handler_log.find(log_db, log_collection, query, True)
	if len(results) == 0:
		insert_raw_version(True)
		
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "finish bit_space")


if __name__ == '__main__':
	tool_config = config.ConfigHandler(__file__)
	bitspace_setting = tool_config.read_configure("tool.ini", "BITSPACE")
	log_setting = tool_config.read_configure("tool.ini", "LOG")

	parser = argparse.ArgumentParser("This is tool that extract the data of bitspace api")
	parser.set_defaults(func=bit_space)
	parser.add_argument("-query", action="store", type=str, help="please input query for BitSpaceLog for recoding log",
	                    default="")
	parser.add_argument("-platform", action="store", type=str,
	                    help="please input platform in BitSpace ex: dianping, ele, baiduwaimai, meituanwm, jd, yhd, "
	                         "tmall or taobao.", default="")
	parser.add_argument("-kind", action="store", type=str,
	                    help="please input kind in BitSpace ex: product, comment or restaurant.", default="")
	parser.add_argument("-pre_collection", action="store", type=str,
	                    help="please input pre collection in our db. ex: PreJDCate", default="")
	parser.add_argument("-dst_collection", action="store", type=str,
	                    help="please input destination collection in out db.", default="")
	parser.add_argument("--range", action="store", type=str,
	                    help="please input range in BitSpace for pre_db format star,pages ex: 0,10. 0 is the start "
	                         "point in pre_db, if start is 10 , the start point is 100000. it had 10 pages if num was 10",
	                    default="")
	parser.add_argument("--page_size", action="store", type=str,
	                    help="please input the page size per one page cursor, default is 10000", default="10000")
	parser.add_argument("--mode", action="store", type=str, help="please input mode in BitSpace. ex: INFO or DEBUG",
	                    default="INFO")
	parser.add_argument("--term", action="store", type=str,
	                    help="please input term for BitSpace comment, ex:2017-01-01", default=None)

	parser.add_argument("--kw", action="store", type=str,
	                    help="please input keyword for BitSpace comment, ex:达芙妮", default=None)
	
	parser.add_argument("--search", action="store", type=str,
						help="please input mongodb script  for BitSpace comment, ex:{'majorTag':'drink'}", default=None)
	parser.add_argument("--searchType", action="store", type=str,
						help="please input searchType parameter  for BitSpace api, ex:--searchType miao", default=None)
	parser.add_argument("--version", action="version", version="0.0.6")

	try:
		dst_ip = bitspace_setting["ip"]
		dst_db = bitspace_setting["db"]

		log_ip = log_setting["ip"]
		log_db = log_setting["db"]
		log_collection = log_setting["collectionlog"]
		error_collection = log_setting["collectionerror"]

		db_handler_dst = mongo.MongoHandler(dst_ip)
		db_handler_log = mongo.MongoHandler(log_ip)

		args = parser.parse_args()
		g_query = args.query
		g_platform = args.platform
		g_kind = args.kind
		g_range = args.range
		g_mode = args.mode
		g_page_size = int(args.page_size)
		g_search_type = args.searchType
		if args.term:
			end = datetime.datetime.strptime(args.term, "%Y-%m-%d")
			start = datetime.datetime(1970, 1, 1)
			gap = int((end - start).total_seconds())
			g_term = datetime.datetime.fromtimestamp(gap, datetime.timezone.utc)
			print(gap)
			print(g_term)
		g_search = args.search
		pprint.pprint(g_search)
		g_kw = args.kw
		pre_collection = args.pre_collection
		dst_collection = args.dst_collection

		g_start = int(g_range.split(",")[0])
		g_num = int(g_range.split(",")[-1])
		g_version = datetime.datetime.strftime(datetime.datetime.today(), "%Y%m")
		print(g_start, g_num)

		logger = init_logger('bit_space_' + g_platform + '_' + g_query, g_mode)
		logger.info("start>>>")

		args.func()
		# main()

		delete_log(g_query)

		db_handler_dst.close_disconnect()
		db_handler_log.close_disconnect()
	except ValueError as e:
		print("the date format was wrong, please input python3 bit_space.py --help")


