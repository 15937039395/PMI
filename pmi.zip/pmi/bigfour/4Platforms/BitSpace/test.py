# coding: UTF-8

from utility import mongo

bit_space_api(**kwargs):
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "start bit_space_api")

	platform = kwargs["platform"]
	kind = kwargs["kind"]
	shop_id = ""
	longitude = ""
	latitude = ""
	cat_id = ""
	kw = ""
	major_tag = ""
	city_id = ""
	if "shop_id" in kwargs:
		shop_id = kwargs["shop_id"]
	if "longitude" in kwargs:
		longitude = kwargs["longitude"]
	if "latitude" in kwargs:
		latitude = kwargs["latitude"]
	if "cat_id" in kwargs:
		cat_id = kwargs["cat_id"]
	if "kw" in kwargs:
		kw = kwargs["kw"]
	if "major_tag" in kwargs:
		major_tag = kwargs["major_tag"]
	if "category" in kwargs:
		category = kwargs["category"]
	if "city_id" in kwargs:
		city_id = kwargs["city_id"]

	if platform == "tmall" or platform == "taobao":
		platform_kind_url = root_url_b + kind + "/" + platform
	else:
		platform_kind_url = root_url_a + kind + "/" + platform

	# calculate the count of API by using
	count_log = db_handler_log.find(log_db, "APILog", {"url": platform_kind_url, "key": g_query}, False)
	if count_log is None:
		count = 0
	else:
		count = count_log["count"]

	# get the page number of this API
	# 四大電商的商品
	if platform in web_shop_cate and kind == "product":
		data_filter = {
			"key": g_query,
			"catId": cat_id
		}
		api_page_log = db_handler_log.find(log_db, "APIPageLog", data_filter, False)
		if api_page_log is None:
			page = 1
		else:
			page = api_page_log["page"]
	# 餐館
	elif kind == "restaurant":
		api_page_log = None
		# 四大電商
		if platform in waimai_platform_cate:
			data_filter = {
				"key": g_query,
				"lon": longitude,
				"lat": latitude,
			}
			api_page_log = db_handler_log.find(log_db, "APIPageLog", data_filter, False)
		# 大眾點評
		elif platform == "dianping":
			data_filter = {
				"key": g_query,
				"cityId": city_id,
			}
			api_page_log = db_handler_log.find(log_db, "APIPageLog", data_filter, False)
		if api_page_log is None:
			page = 1
		else:
			page = api_page_log["page"]
	# 其他 如三大外賣的菜單和大眾點評的評論
	else:
		data_filter = {
			"key": g_query,
			"id": shop_id,
		}
		api_page_log = db_handler_log.find(log_db, "APIPageLog", data_filter, False)
		if api_page_log is None:
			page = 1
		else:
			page = api_page_log["page"]

	while True:
		print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", page, "page data")
		parameter_map = {}
		# 菜單或商品
		if kind == "product":
			# 四大電商 商品的api parameter
			if platform in web_shop_cate:
				parameter_map["catid"] = cat_id
				parameter_map["apikey"] = key
				parameter_map["pageToken"] = page
			# 三大外賣的 菜品的api parameter
			elif platform in waimai_platform_cate:
				parameter_map["id"] = shop_id
				parameter_map["apikey"] = key
		# 餐館
		elif kind == "restaurant":
			# 三大外賣 餐館的api parameter
			if platform in waimai_platform_cate:
				parameter_map["lon"] = longitude
				parameter_map["lat"] = latitude
				parameter_map["apikey"] = key
				parameter_map["pageToken"] = page
			# 大眾點評 餐館的api parameter
			elif platform == "dianping":
				parameter_map["cityid"] = city_id
				parameter_map["catid"] = "10"
				parameter_map["apikey"] = key
				parameter_map["pageToken"] = page
		# 評論
		elif kind == "comment":
			# 大眾點評 評論的api parameter
			if platform == "dianping":
				parameter_map["id"] = shop_id
				parameter_map["type"] = "time"
				parameter_map["apikey"] = key
				parameter_map["pageToken"] = page

		query_string = parse.urlencode(parameter_map)
		print(platform_kind_url, query_string)
		json_data, error_message = common.get_common_api(url=platform_kind_url, query_parameter=query_string)
		if json_data is not None:
			# print(json_data, error_message)
			if "data" in json_data:
				count += 1
				call_api_map = {
					"url": platform_kind_url,
					"key":  g_query,
					"count": count,
				}
				db_handler_log.insert_one(log_db, "APILog", call_api_map, ["url", "key"])
				results = json_data["data"]
				# pprint.pprint(results)
				for i, result in enumerate(results):
					print(i, "th result")
					if kind == "product":
						result["version"] = datetime.datetime.strftime(datetime.datetime.today(), "%Y%m%d")
						if platform == "jd":
							parse_web_shop_json(result, "JD", major_tag, category)
						elif platform == "yhd":
							parse_web_shop_json(result, "Yhd", major_tag, category)
						elif platform == "taobao":
							parse_web_shop_json(result, "Taobao", major_tag, category)
						elif platform == "tmall":
							parse_web_shop_json(result, "Tmall", major_tag, category)
						elif platform == "ele":
							db_handler_dst.insert_one(dst_db, "ElemeMenu", result, ["id"])
						elif platform == "baiduwaimai":
							db_handler_dst.insert_one(dst_db, "WaimaiBaiduMenu", result, ["id"])
						elif platform == "meituanwm":
							db_handler_dst.insert_one(dst_db, "WaimaiMeituanMenu", result, ["id"])
					elif kind == "restaurant":
						result["version"] = datetime.datetime.strftime(datetime.datetime.today(), "%Y%m%d")
						if platform == "ele":
							parse_waimai_json(result, "Eleme")
						elif platform == "baiduwaimai":
							parse_waimai_json(result, "WaimaiBaidu")
						elif platform == "meituanwm":
							parse_waimai_json(result, "WaimaiMeituan")
						elif platform == "dianping":
							parse_dianping_json(result)
					elif kind == "comment":
						if platform == "dianping":
							parse_dianping_comment_json(result)
				if kind == "product":
					pass
				elif kind == "restaurant":
					pass
				elif kind == "comment":
					if platform == "dianping":
						if g_term > datetime.datetime.fromtimestamp(results[-1]["publishDate"], datetime.timezone.utc):
							logger.info(str(shop_id) + " is completed and the last extract " + str(
								datetime.datetime.fromtimestamp(results[-1]["publishDate"], datetime.timezone.utc)))
							break

			elif "message" in json_data:
				url = platform_kind_url + "?" + query_string
				if json_data["message"] == "search no result":
					logger.info("url: %s search no result", url)
					break
				elif json_data["message"] == "Server internal error":
					logger.info("url: %S Server internal error", url)
					continue
				else:
					logger.info("url: %s  message: %s", url, json_data["message"])
					continue
			else:
				logger.info("other error: " + str(json_data))
				continue

			if "hasNext" in json_data:
				if json_data["hasNext"] is False:
					break
		else:
			# logger.exception(error_message)
			print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "error message", error_message)
			error_map = {
				"shopId": shop_id,
				"key": g_query,
				"platform": platform,
				"kind": kind,
				"page": page,
				"errorMessage": error_message
			}
			db_handler_log.insert_one(log_db, error_collection, error_map, ["key", "shopId", "platform", "kind", "page", "errorMessage"])
			continue

		page += 1
		if kind == "product":
			if platform in web_shop_cate:
				api_page_log_map = {
					"platform": g_platform,
					"kind": g_kind,
					"cat_id": cat_id,
					"key": g_query,
					"page": page
				}
				db_handler_log.insert_one(log_db, "APIPageLog", api_page_log_map, ["key", "kind", "cat_id"])
			elif platform in waimai_platform_cate:
				api_page_log_map = {
					"platform": g_platform,
					"kind": g_kind,
					"key": g_query,
					"id": shop_id,
					"page": page
				}
				db_handler_log.insert_one(log_db, "APIPageLog", api_page_log_map, ["id", "kind", "key"])
		elif kind == "restaurant":
			if platform in web_shop_cate:
				pass
			elif platform in waimai_platform_cate:
				api_page_log_map = {
					"platform": g_platform,
					"kind": g_kind,
					"key": g_query,
					"lon": longitude,
					"lat": latitude,
					"page": page
				}
				db_handler_log.insert_one(log_db, "APIPageLog", api_page_log_map, ["lon", "lat", "kind", "key"])
			elif platform == "dianping":
				api_page_log_map = {
					"platform": g_platform,
					"kind": g_kind,
					"key": g_query,
					"cityId": city_id,
					"page": page
				}
				db_handler_log.insert_one(log_db, "APIPageLog", api_page_log_map, ["cityId", "kind", "key"])
		else:
			api_page_log_map = {
				"platform": g_platform,
				"kind": g_kind,
				"key": g_query,
				"id": shop_id,
				"page": page
			}
			db_handler_log.insert_one(log_db, "APIPageLog", api_page_log_map, ["id", "kind", "key"])
		time.sleep(0.125)

	# db_handler_log.delete(log_db, "APILog", delete_filter, False)
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "finish bit_space_api")

if __name__ == '__main__':
	db_handler = mongo.MongoHandler("")
	results = db_handler.find("Octavius", "JD", {}, True)
	print(len(results))
	"""
	data_filter = {
		"isShutdown": {
			"$ne": 1
		},
		"country": "中国",
		"bigCate": "美食",
		"commentCount": {
			"$gte": 0
		}
	}

	results = db_handler.get_cursor("Octavius", "Dianping", data_filter).sort("key")
	print(results.count())
	results.close()
	"""
	"""
	for i, result in enumerate(results):
		print(i, "th", result["shopId"])
		doc = {
			"th": i + 1,
			"shopId": result["shopId"],
			"shopName": result["Name"]
		}
	db_handler.insert_one("HenryTest", "DianpingShopId", doc, ["shopId"])
	print(len(results))
	"""