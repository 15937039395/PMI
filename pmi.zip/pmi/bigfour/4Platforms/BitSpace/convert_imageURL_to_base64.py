# coding: UTF-8

import argparse

from utility import common, mongo, log, config


def main():
	log.tag(__name__).info("Start convert")
	data_filter = {
		"images": {
			"$exists": False
		}
	}
	results = db_handler.get_cursor(db, g_platform, data_filter)
	count = 0
	while True:
		if not results.alive:
			break
		count += 1
		try:
			result = results.next()
			log.tag(__name__).info("%d th id: %s", count, result["id"])
			image = common.get_image_data_uri2(result["imageUrls"][0])
			result["images"] = [image]
			db_handler.insert_one(db, g_platform, result, ["_id"])
		except Exception as e:
			log.tag(__name__).exception(str(e))

	results.close()
	log.tag(__name__).info("finish convert")


if __name__ == '__main__':
	tool_config = config.ConfigHandler(__file__)
	bitspace_setting = tool_config.read_configure("tool.ini", "BITSPACE")
	parser = argparse.ArgumentParser(
		"This is tool that covert image url to base64 for  the data of bitspace api and version is 0.0.1")
	parser.set_defaults(func=main)
	parser.add_argument("-platform", action="store", type=str, help="please input platform in BitSpace", default="")
	parser.add_argument("--mode", action="store", type=str, help="please input mode in BitSpace", default="INFO")

	ip = bitspace_setting["ip"]
	db = bitspace_setting["db"]

	db_handler = mongo.MongoHandler(ip)

	args = parser.parse_args()
	g_mode = args.mode
	g_platform = args.platform

	log.set_level(g_mode)

	args.func()

	db_handler.close_disconnect()

