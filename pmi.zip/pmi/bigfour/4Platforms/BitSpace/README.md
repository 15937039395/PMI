# BitSpace

To extract the data of  Bitspace API