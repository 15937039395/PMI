#coding:UTF-8

import logging
import requests
import base64
import json

class HGAPI:
	cm_api_url="http://123.51.165.168:2080/cm"
	hgbl_api_url="http://123.51.165.168:2080/hgbl"

	def __init__(self):
		self._logger = logging.getLogger('mongo')
		self.token = None
		self.tasks = []
		self._logger.info("HGAPI initialized")

	def login(self, account, password, url=hgbl_api_url+"/api/token"):
		'''
		account: String
		password: String
		return status
		'''
		try:
			header_map = {}
			login_string = account + ":" +password
			base64_string = base64.b64encode(bytes(login_string, encoding='UTF-8')).decode('UTF-8')
			header_map["Authorization"] = "Basic " + base64_string
			header_map["Content-Type"] = "application/json"
			response = requests.get(url=url, headers=header_map)
			content = response.content.decode("UTF-8")
			json_content = json.loads(content)
		except Exception as e:
			self._logger().exception(str(url) + ' login exception: ' + str(e))
			return None
		else:
			header_map = None
			self.token = json_content["data"]["accessToken"]
			return json_content['status']

	def get_hgbl_geo_info(self, request_param, url=hgbl_api_url+"/api/geoinfo"):
		'''
		request_param: Dictionary
		return: json
		'''
		try:
			header_map = {}
			header_map["Authorization"] = "Bearer " + self.token
			header_map["Content-Type"] = "application/json"
			urlencode_string = parse.urlencode(request_param)
			response = requests.get(url=url, params=request_param)
			content = response.content.decode("UTF-8")
			json_content = json.loads(content)
		except Exception as e:
			self._logger().exception(str(url) + ' get_hgbl_geo_info exception: ' + str(e))
			return None
		else:
			return json_content

	def create_crawler_task(self, job_id, url=cm_api_url+"/api/crawler/task"):
		'''
		job_id: String
		return json
		'''
		try:
			header_map = {}
			req_body = {}
			header_map["Authorization"] = "Bearer " + self.token
			header_map["Content-Type"] = "application/json"
			req_body["jobId"] = job_id
			#you can also use
			#response = requests.request(method="POST", url=url, headers=header_map, json=req_body)
			response = requests.post(url=url, headers=header_map, json=req_body)
			content = response.content.decode("UTF-8")
			json_content = json.loads(content)
		except Exception as e:
			self._logger().exception(str(url) + ' create_crawler_task exception: ' + str(e))
			return None
		else:
			header_map = None
			return json_content

	def finish_crawler_task(self, task_id, url=cm_api_url+"/api/crawler/task/"):
		'''
		task_id: String
		return json
		'''
		try:
			header_map = {}
			header_map["Authorization"] = "Bearer " + self.token
			header_map["Content-Type"] = "application/json"
			response = requests.put(url=url+task_id+"/finish", headers=header_map)
			content = response.content.decode("UTF-8")
			json_content = json.loads(content)
		except Exception as e:
			self._logger().exception(str(url) + ' finish_crawler_task exception: ' + str(e))
			return None
		else:
			header_map = None
			return json_content

	def ping_crawler_task(self, task_id, total_number, update_number, url=cm_api_url+"/api/crawler/task/"):
		'''
		task_id: String
		return json
		'''
		try:
			header_map = {}
			req_body = {}
			header_map["Authorization"] = "Bearer " + self.token
			header_map["Content-Type"] = "application/json"
			req_body["updateNumber"] = update_number
			req_body["totalNumber"] = total_number
			response = requests.put(url=url+task_id+"/ping", headers=header_map, json=req_body)
			content = response.content.decode("UTF-8")
			json_content = json.loads(content)
		except Exception as e:
			self._logger().exception(str(url) + ' ping_crawler_task exception: ' + str(e))
			return None
		else:
			header_map = None
			return json_content
