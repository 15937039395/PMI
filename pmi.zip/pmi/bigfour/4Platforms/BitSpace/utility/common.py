#coding:utf-8

"""
Created on 2016年5月17日

@author: shane
"""

import logging
import base64
import json
import time
import urllib.request
import getopt
import sys
import os
import platform
import random
import http.client
import math


import requests
import requests.adapters
import pickle


from datetime import datetime, date, timedelta
from math import radians, cos, sin, asin, sqrt, atan2

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.proxy import *
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from urllib import request, parse
from pytube import YouTube
from base64 import b64encode

#from pytesseract.pytesseract import image_to_string
from PIL import Image
from getopt import GetoptError

try:
	from urllib2 import urlopen
except ImportError:
	from urllib.request import urlopen

fmt = (
	'%Y-%m-%d %H:%M',
	'%m月%d日 %H:%M',
	'%m月%d日%H:%M',
	'%m-%d %H:%M',
	'%Y-%m-%d %H:%M:%S',
	'%Y-%m-%d',
	'%Y年%m月%d日 %H:%M',
	'%Y年%m月%d日%H:%M',
	'%Y年%m月%d日 %H:%M:%S',
	'%Y年%m月%d日%H:%M:%S',
	'%Y年%m月%d日%H：%M',
	' %Y-%m-%d %H:%M:%S',
	'(%Y-%m-%d %H:%M:%S)',
	'(%Y-%m-%d)',
	'%Y.%m.%d ',
	'%Y.%m ',
	'%Y. ',
	'%Y年%m月%d日',
	'%Y 年%m月%d日',
	'%Y年%m月',
	'%m月%d日'
	)
fmt_switch = {
			'0':(fmt[0], ''),
			'1':('%Y' + '-' + fmt[1], time.strftime('%Y') + '-'),
			'2':('%Y' + '-' + fmt[2], time.strftime('%Y') + '-'),
			'3':('%Y' + '-' + fmt[3], time.strftime('%Y') + '-'),
			'4':(fmt[4], ''),
			'5':(fmt[5], ''),
			'6':(fmt[6], ''),
			'7':(fmt[7], ''),
			'8':(fmt[8], ''),
			'9':(fmt[9], ''),
			'10':(fmt[10], ''),
			'11':(fmt[11], ''),
			'12':(fmt[12], ''),
			'13':(fmt[13], ''),
			'14':(fmt[14], ''),
			'15':(fmt[15], ''),
			'16':(fmt[16], ''),
			'17':(fmt[17], ''),
			'18':(fmt[18], ''),
			'19':(fmt[19], ''),
			'20':('%Y' + '年' + fmt[20], time.strftime('%Y') + '年')
			}

'''
#二值化
threshold = 140
table = []

for i in range(256):
	if i < threshold:
		table.append(0)
	else:
		table.append(1)

rep = {'O':0, 'I':1, 'L':1, 'Z':2, 'S':8}
'''

cm_api_url="http://123.51.165.168:2080/cm"
hgbl_api_url="http://123.51.165.168:2080/hgbl"


def _get_logger():
	return logging.getLogger('common')


def sleep(secs):
	'''
	睡上幾秒

	Args:
		secs: 秒數
	'''
	_get_logger().debug('sleeping in ' + repr(secs) + ' secs')
	time.sleep(secs)


def random_sleep():
	'''
	隨機睡覺
	'''
	secs = random.randrange(1, 10)
	_get_logger().debug('sleeping in ' + repr(secs) + ' secs')
	time.sleep(secs)


def wait(driver, sec):
	'''
	隱性等待，但比較沒用

	Args:
		driver: webdriver物件
		seconds: 等待秒數
	 '''
	driver.implicitly_wait(sec)


def wait_until(driver, seconds, css_selector):
	'''
	等待網頁處理，直到目標DOM存在
	若超過指定時間則throw exception

	Args:
		driver: webdriver物件
		seconds: 等待秒數
		css_selector: 判斷是否結束等待的selector
	'''
	WebDriverWait(driver, seconds).until(
			EC.presence_of_all_elements_located((By.CSS_SELECTOR, css_selector)))


def page_down(driver):
	'''
	將網頁卷軸拉到底部

	Args:
		driver: webdriver物件
	'''
	driver.execute_script('window.scrollTo(0, document.body.scrollHeight);')


def get_image_data_uri(pic_url):
	'''
	將圖片網址轉為DataURI格式，以利前端網頁直接呈現

	Args:
		pic_url: 圖片網址
	'''
	try:
		ext = pic_url.split('.')[-1]
		headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64)'}
		req = urllib.request.Request(pic_url, None, headers)
		resp = urllib.request.urlopen(req)
		enc_str = str(base64.b64encode(resp.read()))[2:-1]
		return 'data:image/' + ext + ';base64,' + enc_str
	except Exception as e:
		_get_logger().exception(str(pic_url) + ' get_image_data_uri exception: ' + str(e))
	return ''


def get_image_data_uri2(pic_url):
	uri = ''
	try:
		headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64)'}
		#print('get_image_data_uri2', pic_url)
		response = requests.get(pic_url, headers = headers)
		uri = 'data:' + response.headers['Content-Type'] + ';' + 'base64,' + str(base64.b64encode(response.content))[2:-1]
	except Exception as e:
		_get_logger().exception(str(pic_url) + ' get_image_data_uri2 exception: ' + str(e))
	else:
		return uri


def read_config_as_json(flie_name):
	'''
	(開發中)讀取同目錄下的設定檔
	'''
	file = open(flie_name, 'r', encoding='UTF-8')
	content = file.read()
	print(content)
	jsonObj = json.dump(content)
	file.close()


def click_until(driver, css_selector, second):
	i = 0
	while True:
		try:
			driver.find_element_by_css_selector(css_selector)
			print('element had been find')
			return True
		except Exception as e:
			print('element can not find')
			time.sleep(1)
			i = i + 1
			if second == i:
				return False


def recognize_time_format(string, time_fmt, switch):
	"""
	parse time format like Y-m-d H:M, m-d H:M, t
	recognize time format
	combine string of time
	parameter	: text, time format array and dictionary switch
	ex: 2016-05-30 18:30
		fmt = ('%Y-%m-%d %H:%M', '%m-%d %H:%M')
		switch = {
			  '0':'',
			  '1':time.strftime("%Y") + '-'
			  }
	if it is recognized time format and
	return string of time
	"""
	for i in range(0, len(time_fmt)):
		try:
			datetime.strptime(string, time_fmt[i])
			print('switch', switch[str(i)])
			return switch[str(i)]
		except Exception as ValueError:
			print('Exception', ValueError)
	return ''

'''
def normal_ocr(file_name):
	img = Image.open(file_name)
	img.show()
	#builtins.open = bin_open
	#bts = image_to_string(img)
	#print(str(len(bts)))
	#print(str(bts, 'cp1252', 'ignore'))
	imgstr = image_to_string(img)
	print(imgstr)

def enhance_orc(file_name):
	img = Image.open(file_name)
	img_gry = img.convert('L')
	img_gry.show()
	out = img_gry.point(table, '1')
	out.show()
	imgstr = image_to_string(out)
	print(str(len(imgstr)))
	print(imgstr)
'''


def command(cmnd_line):

	'''
	應該會移除掉
	default
	pages = -1
	match = True
	the opt "-k"  must put to the last of the command line
	-m input 'T' or 'F'
	'''

	print('command: ', cmnd_line)
	cmd_map ={}
	cmd_map['q'] = ''
	cmd_map['p'] = -1
	cmd_map['l'] = ""
	cmd_map['i'] = ""
	try:
		opts, args = getopt.getopt(cmnd_line, 'h:q:p:d:a:i:o:m:l:')
		print('opts:', opts)
		print('args:', args)
	except GetoptError as e:
		_get_logger().exception('command error:' + e)
		sys.exit(2)
		return None
	for opt, para in opts:
		if opt == '-h':
			print('this is help')
		elif opt in ('-q'):
			'''
			keyword = para
			for arg in args:
				keyword = keyword + arg
			cmd_map['q'] = keyword
			'''
			cmd_map['q'] = para
		elif opt in ('-p'):
			cmd_map['p'] = para
		elif opt in ('-i'):
			cmd_map['i'] = para
		elif opt in ('-o'):
			cmd_map['o'] = para
		elif opt in ('-l'):
			cmd_map['l'] = para
		elif opt in ('-m'):
			if para == 'T':
				cmd_map['match'] = True
			elif para == 'F':
				cmd_map['match'] = False
	#print('keyword:', keyword)
	#print('pages:', pages)
	#print('db_name:', db_name)
	#print('ip:', ip)
	#print('file_path: ', file_path)
	#print('output: ', output)
	#print('match: ', match)

	return cmd_map


def prepare_firefox_profile(download_location):
	'''
	自訂Firefox的下載路徑及有關參數，避免檔案下載時被詢問視窗卡住
	範例：
		fp = prepare_firefox_profile('c:\\downloads')
		driver = webdriver.Firefox(firefox_profile = fp)
		driver.get(YOUR_URL)

	註1: 下載路徑要以「\\」分隔，若用「/」好像會失效。可從選項中檢查是否有生效。
	註2: 有可能還是會跳出下載詢問視窗，請檢查下載檔案的content-type是否已被涵蓋，否則請持續擴充。
	註3: 上述情況，就算加入了新的content-type，還是會有跳出視窗的問題，目前無解，可用爛方式(第一次sleep久一點，手動選擇自動下載並不再詢問，後續就OK了)。

	Args:
		download_location: 檔案下載存放的絕對路徑

	Returns:
		FirefoxProfile object
	'''

	mime_pdf_types = 'application/pdf,application/vnd.adobe.xfdf,application/vnd.fdf,application/vnd.adobe.xdp+xml,application/x-pdf'
	fp = webdriver.FirefoxProfile()
	fp.set_preference('browser.download.folderList', 2) # 0=桌面, 1=我的下載, 2=自訂
	fp.set_preference('browser.download.manager.showWhenStarting', False)
	fp.set_preference('browser.download.dir', download_location)
	fp.set_preference('browser.helperApps.neverAsk.saveToDisk', 'text/html,text/plain,text/csv,application/csv,application/download,application/octet-stream,application/octet-stream,video/mp4,image/png,application/vnd.ms-excel,' + mime_pdf_types)
	fp.set_preference("plugin.disable_full_page_plugin_for_types", mime_pdf_types)
	fp.set_preference("pdfjs.disabled", "true")

	return fp


def write_output_as_json(path, output_list):
	file_name = str(time.time()).replace('.', '_')
	with open(path+file_name+'.json', 'w', encoding='UTF-8') as output_file:
		for line in output_list:
			output_file.write('%s\n' % line)
		output_file.close()


def get_geo_poi_baidu(query_data, url='http://api.map.baidu.com/place/v2/search'):
	try:
		url_open = request.urlopen(url + '?' + query_data)
		response = ''
		while True:
			try:
				response_part = url_open.read()
			except http.client.IncompleteRead as icread:
				_get_logger().exception(query_data + ' IncompleteRead:' + str(icread.partial.decode('utf-8')))
				response = response + icread.partial.decode('utf-8')
				continue
			else:
				response = response + response_part.decode('utf-8')
				break
		try:
			return json.loads(response), ''
		except ValueError as e:
			_get_logger().exception(query_data + ' exception ValueError: ' + str(e))
			return None, str(e)
	except Exception as e:
		_get_logger().exception(query_data + ' exception error: ' + str(e))
		return None, str(e)
	except urllib.error.URLError as e:
		error_reason = e.reason()
		_get_logger().exception(query_data + ' exception urllib.error.URLError: ' + "error reason:" + error_reason)
		return None, str(e)
	except urllib.error.HTTPError as e:
		error_code = e.code()
		error_reason = e.reason()
		error_header = e.headers()
		_get_logger().exception(query_data + ' exception urllib.error.HTTPError: ' + "error code:" + error_code + " error reason:" + error_reason + " error header:" + error_header)
		return None, str(e)


def load_cookies(soure_file, cookie_file):
	cookie_path = os.path.dirname(os.path.abspath(soure_file))
	cookies = pickle.load(open(cookie_path + '/' + cookie_file, "rb"))
	return cookies


def load_file(programe_name, file_name):
	parent_path = os.path.dirname(os.path.abspath(programe_name))
	if platform.system() == 'Windows':
		file_path = parent_path + '\\' + file_name
	elif platform.system() == 'Linux' or platform.system() == 'Darwin': #Linux or Mac
		file_path = parent_path + '/' + file_name
	return file_path


def get_youtube_source(url):
	'''
	'''
	prefix_name = 'download'
	suffix_name = 'Complete'
	source =  b''
	byte_received = 0
	start = 0
	chunck_size = 255*1024
	yt = YouTube(url)
	video = yt.get('mp4', '360p')
	response = urlopen(video.url)
	meta_data = dict(response.info().items())
	content_type = meta_data.get('content-type') or meta_data.get('Content-Type')
	file_size = int(meta_data.get("Content-Length") or
					meta_data.get("content-length"))
	FILE_SIZE = '%.2f MB' % round(float(file_size / (1024*1024)), 2)
	#print('%.2f MB' % round(float(file_size / (1024*1024)), 2))
	if file_size % chunck_size is 0:
		length = int(file_size / chunck_size)
	else:
		length = int(file_size / chunck_size) + 1
	printProgress(start, length, prefix = FILE_SIZE, suffix = suffix_name, barLength = 50)
	while True:
		try:
			buf = response.read(chunck_size)
			#print(buf)
			#print(byte_received)
			if not buf:
				break
			byte_received += len(buf)
			source += buf
			start += 1
			printProgress(start, length, prefix = FILE_SIZE, suffix = suffix_name, barLength = 50)
		except Exception as e:
			raise
		else:
			pass
	name = video.filename + '.' + video.extension
	metadata = {'Content-Type':content_type}
	return name, source, metadata


# Print iterations progress
def printProgress (iteration, total, prefix = '', suffix = '', decimals = 1, barLength = 100, fill = '█'):
	"""
	Call in a loop to create terminal progress bar
	@params:
		iteration   - Required  : current iteration (Int)
		total       - Required  : total iterations (Int)
		prefix      - Optional  : prefix string (Str)
		suffix      - Optional  : suffix string (Str)
		decimals    - Optional  : positive number of decimals in percent complete (Int)
		barLength   - Optional  : character length of bar (Int)
	"""
	percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
	filledLength = int(barLength * iteration // total)
	bar = fill * filledLength + '-' * (barLength - filledLength)
	sys.stdout.write('\r%s |%s| %s%s %s' % (prefix, bar, percent, '%', suffix)),
	if iteration == total:
		sys.stdout.write('\n')
	sys.stdout.flush()


def set_proxy_profile(ip='proxy.seed.net.tw', port='8080', exten_path=''):
	'''
	set profile for proxy and proxy type always manual
	default ip is proxy.seed.net.tw and pory is 8080
	@params:
		ip   - Required : proxy IP (string)
		port - Required : proxy port (string)
	'''
	fp = webdriver.FirefoxProfile()
	proxy_map = {}
	my_proxy = ip + ':' + port
	proxy_map['proxyType'] = 1	#ProxyType.MANUAL
	proxy_map['host'] = ip
	proxy_map['port'] = port
	proxy_map['usr'] = 'system'
	proxy_map['pwd'] = 's20b1sno'
	fp.add_extension(exten_path)
	fp.set_preference('network.proxy.type', 1)
	fp.set_preference('network.proxy.http', proxy_map['host'])
	fp.set_preference('network.proxy.http_port', int(proxy_map['port']))
	credentials = '{usr}:{pwd}'.format(**proxy_map)
	credentials = b64encode(credentials.encode('ascii')).decode('utf-8')
	fp.set_preference('extensions.closeproxyauth.authtoken', credentials)
	#proxy_map['socksUsername'] = 'system'
	#proxy_map['socksPassword'] = 's20b1sno'
	#proxy = Proxy(proxy_map)
	#Proxy
	return fp


def driver_get_url_with_timeout(driver, url, second):
	try:
		driver.set_page_load_timeout(second)
		driver.get(url)
	except Exception as e:
		print('driver had timeout')
		#_get_logger().info('driver had timeout')
	else:
		#_get_logger().info('driver had not timeout')
		print('driver had no timeout')


def check_element_by_css_selector_click(driver, name):
	try:
		driver.find_element_by_css_selector(name).click()
	except Exception as e:
		return False
	else:
		return True


def check_element_by_css_selector_text(driver, name):
	try:
		value = driver.find_element_by_css_selector(name).text
	except Exception as e:
		_get_logger().exception('check_element_by_css_selector' + ' ' + name + ' ' + str(e))
		return ''
	else:
		return value


def get_proxy_list(api_url='http://123.51.165.168:2080/fastproxy/'):
	try:
		response = requests.get(api_url)
		#print(response.content.decode('utf-8'))
		content = response.content.decode('utf-8')
		json_content = json.loads(content)
		#json_data = json.loads(json_content["data"])

	except Exception as e:
		return 	_get_logger().exception('get_proxy_list' + ' ' + str(e))
	else:
		#print(json_content["data"]["proxy_list"][1])

		return json_content["data"]["proxy_list"]


def get_data_for_api(url):
	try:
		response = requests.get(url)
		#print(response.content.decode('utf-8'))
		content = response.content.decode('utf-8')
		json_content = json.loads(content)
		#json_data = json.loads(json_content["data"])

	except Exception as e:
		_get_logger().exception('get_data_for_api' + ' ' + str(e))
		return None
	else:
		#print(json_content["data"]["proxy_list"][1])
		return json_content


def get_hgbl_token(login_string, url=hgbl_api_url+'/api/token'):
	try:
		base64_string = base64.b64encode(bytes(login_string, encoding='UTF-8')).decode('utf-8')
		req = request.Request(url)
		req.add_header('Authorization', 'Basic ' + base64_string)
		resp = request.urlopen(req)
		content = resp.read().decode('utf-8')
		json_data = json.loads(content)
	except Exception as e:
		_get_logger().exception(str(url) + ' get_token exception: ' + str(e))
		return None
	else:
		return json_data['data']['accessToken']


def get_hgbl_geo_info(token, request_data, url= hgbl_api_url + '/api/geoinfo'):
	try:
		param = {}
		param['q'] = str(request_data)
		urlencode_string = parse.urlencode(param)
		req = request.Request(url + '?' + urlencode_string)
		req.add_header('Authorization', 'Bearer ' + token)
		resp = request.urlopen(req)
		response_data = resp.read().decode('utf-8')
		json_data = json.loads(response_data)
	except Exception as e:
		_get_logger().exception(str(url) + ' get_geo_info exception: ' + str(e))
		return {}
	else:
		return json_data


def create_cm_task(job_id, token, url=cm_api_url+"/api/crawler/task/"):
	'''
	create an new task of crawler task
	It will be return task ID
	'''
	try:
		header_map = {}
		req_body = {}
		header_map["Authorization"] = "Bearer " + token
		req_body["jobId"] = job_id
		# you can also use
		# response = requests.request(method="POST", url=url, headers=header_map, json=req_body)
		response = requests.post(url=url, headers=header_map, json=req_body)
		content = response.content.decode('utf-8')
		json_content = json.loads(content)

	except Exception as e:
		_get_logger().exception(str(url) + ' create_cm_task exception: ' + str(e))
		return None
	else:
		if json_content["status"] == "1":
			return json_content["data"]


def get_baidu_poi(query_data, url='http://api.map.baidu.com/place/v2/search'):
	'''
	Call the Baidu Place API
	@params:
		query_data - (String) Required : the Baidu param after doing parse.urlencode
		url - (String) Required : the Baidu API URL
	'''
	query_url = url + "?" + query_data
	response = ""
	try:
		response = requests.get(url=query_url)
		content = response.content.decode('utf-8')
		json_content = json.loads(content)
	except requests.ConnectionError as e:
		_get_logger().exception('get_baidu_poi requests.ConnectionError ' + str(e))
		return None, str(e)
	except requests.Timeout as e:
		_get_logger().exception('get_baidu_poi requests.Timeout ' + str(e))
		return None, str(e)
	except requests.HTTPError as e:
		_get_logger().exception('get_baidu_poi requests.HTTPError' + ' ' + str(e))
		return None, str(e)
	except Exception as e:
		_get_logger().exception('get_baidu_poi Exception' + ' ' + str(e))
		return None, str(e)
	else:
		return json_content, ""


def get_qq_poi(query_data, url='http://apis.map.qq.com/ws/place/v1/search'):
	"""
	Call the QQ Place API
	:param query_data: (string) Required : the QQ param after doing parse.urlencode
	:param url: (string) Required : the Baidu API URL
	:return: json format and error_message
	"""

	query_url = url + "?" + query_data
	response = ""
	try:
		response = requests.get(url=query_url)
		content = response.content.decode('utf-8')
		json_content = json.loads(content)
	except requests.ConnectionError as e:
		_get_logger().exception('get_qq_poi requests.ConnectionError ' + str(e))
		return None, str(e)
	except  requests.Timeout as e:
		_get_logger().exception('get_qq_poi requests.Timeout ' + str(e))
		return None, str(e)
	except requests.HTTPError as e:
		_get_logger().exception('get_qq_poi requests.HTTPError' + ' ' + str(e))
		return None, str(e)
	except Exception as e:
		_get_logger().exception('get_qq_poi Exception' + ' ' + str(e))
		return None, str(e)
	else:
		return json_content, ""


def get_qq_geocoder_addrees(query_data, url="http://apis.map.qq.com/ws/geocoder/v1/?address="):
	"""
	Call the QQ geocoder address
	@param:
		query_data - (String) Required : the QQ param after doing parse.urlencode
	"""

	query_url = url + "?" + query_data
	response = ""
	try:
		response = requests.get(url=query_url)
		content = response.content.decode('utf-8')
		json_content = json.loads(content)
	except requests.ConnectionError as e:
		_get_logger().exception('get_qq_geocoder_addrees requests.ConnectionError ' + str(e))
		return None, str(e)
	except requests.Timeout as e:
		_get_logger().exception('get_qq_geocoder_addrees requests.Timeout ' + str(e))
		return None, str(e)
	except requests.HTTPError as e:
		_get_logger().exception('get_qq_geocoder_addrees requests.HTTPError' + ' ' + str(e))
		return None, str(e)
	except Exception as e:
		_get_logger().exception('get_qq_geocoder_addrees Exception' + ' ' + str(e))
		return None, str(e)
	else:
		return json_content, ""


def get_qq_lbs_api(query_data, url):
	"""
	Call the QQ Place API
	@params:
		query_data - (String) Required : the QQ param after doing parse.urlencode
		url - (String) Required : the Baidu API URL
	"""
	query_url = url + "?" + query_data
	# response = ""
	try:
		response = requests.get(url=query_url)
		content = response.content.decode('utf-8')
		json_content = json.loads(content)
	except requests.ConnectionError as e:
		_get_logger().exception('get_qq_lbs_api requests.ConnectionError ' + str(e))
		return None, str(e)
	except requests.Timeout as e:
		_get_logger().exception('get_qq_lbs_api requests.Timeout ' + str(e))
		return None, str(e)
	except requests.HTTPError as e:
		_get_logger().exception('get_qq_lbs_api requests.HTTPError' + ' ' + str(e))
		return None, str(e)
	except Exception as e:
		_get_logger().exception('get_qq_lbs_api Exception' + ' ' + str(e))
		return None, str(e)
	else:
		return json_content, ""


def set_total_page(total, size):
	"""
	calculate total pages
	:param total: (int)total item
	:param size: (int)how many items in page
	:return: (int) how many page
	"""

	if total % size == 0:
		pages = int(total / size)
	else:
		pages = int(total / size) + 1

	return pages


def get_common_api(url, query_parameter, timeout=None):
	"""

	:param url:
	:param query_parameter:
	:param timeout:
	:return:
	"""
	query_url = url + "?" + query_parameter
	requests.adapters.DEFAULT_RETRIES = 5
	try:
		_get_logger().debug("requests get start")
		response = requests.get(url=query_url, timeout=timeout)
		content = response.content.decode('utf-8')
		json_content = json.loads(content)
		_get_logger().debug("requests get finish")
	except requests.ConnectionError as e:
		_get_logger().exception('get_common_api requests.ConnectionError ' + str(e))
		return None, str(e)
	except requests.Timeout as e:
		_get_logger().exception('get_common_api requests.Timeout ' + str(e))
		return None, str(e)
	except requests.HTTPError as e:
		_get_logger().exception('get_common_api requests.HTTPError' + ' ' + str(e))
		return None, str(e)
	except Exception as e:
		_get_logger().exception('get_common_api Exception' + ' ' + str(e))
		return None, str(e)
	else:
		return json_content, None


def recalculate_coordinate(val,  _as=None):
	""" 
	Accepts a coordinate as a tuple (degree, minutes, seconds) 
	You can give only one of them (e.g. only minutes as a floating point number) and it will be duly 
	recalculated into degrees, minutes and seconds. 
	Return value can be specified as 'deg', 'min' or 'sec'; default return value is a proper coordinate tuple. 
	"""
	deg,  min,  sec = val
	# pass outstanding values from right to left
	min = (min or 0) + int(sec) / 60
	sec = sec % 60
	deg = (deg or 0) + int(min) / 60
	min = min % 60
	# pass decimal part from left to right
	dfrac,  dint = math.modf(deg)
	min = min + dfrac * 60
	deg = dint
	mfrac,  mint = math.modf(min)
	sec = sec + mfrac * 60
	min = mint
	if _as:
		sec = sec + min * 60 + deg * 3600
		if _as == 'sec': return sec
		if _as == 'min': return sec / 60
		if _as == 'deg': return sec / 3600
	return deg,  min,  sec


def calcuate_distance_by_geo_point(geo_point_a, geo_point_b):
	"""
	Calculate the great circle distance between two points.
	:param geo_point_a: A data map, include key "longitude", "latitude"
	:param geo_point_b: A data map, include key "longitude", "latitude"
	:return distance: a distance by mile
	"""
	print("[", time.strftime('%Y-%m-%d %H:%M:%S'), "]", "start calcuate_distance_by_geo_point")
	r = 3963.2

	lat1 = radians(geo_point_a[0])
	lon1 = radians(geo_point_a[1])
	lat2 = radians(geo_point_b[0])
	lon2 = radians(geo_point_b[1])

	dlon = lon2 - lon1
	dlat = lat2 - lat1

	a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
	c = 2 * atan2(sqrt(a), sqrt(1 - a))

	distance = r * c
	return distance


def short_bubble_sort(data_list):
	"""
	
	:param data_list: 
	:return: 
	"""
	for i in range(len(data_list)):
		flag = False
		for j in range(0, len(data_list)-1-i):
			if data_list[j] < data_list[j + 1]:
				flag = True
				temp = data_list[j]
				data_list[j] = data_list[j + 1]
				data_list[j + 1] = temp
			# print("pass", i + 1, ": ", data_list)
		if not flag:
			break

	return data_list


def map_value_to_list(datas, keys):
	"""
	unit level 4
	:param datas: 
	:param key: the name of field in data_map
	:return: 
	"""
	level = len(keys)
	values = []
	for i, data in enumerate(datas):
		# print(i, "th", data)
		if level == 1:
			values.append(data[keys[0]])
		elif level == 2:
			values.append(data[keys[0]][keys[1]])
		elif level == 3:
			values.append(data[keys[0]][keys[1]][keys[2]])
		elif level == 4:
			values.append(data[keys[0]][keys[1]][keys[2]][keys[3]])

	return values


def convert_datetime_to_second(date_time):
	"""
	
	:param date_time: 
	:return: 
	"""
	second = int(time.mktime(date_time.timetuple()))
	return second


def key_dict_by_value(data_map, target):
	"""
	
	:param data_map: 
	:param target: 
	:return: 
	"""
	for key, value in data_map.items():
		if value == target:
			return key


def merge_two_dict(dict_a, dict_b):
	"""
	merge two dict, a = {'a':1}, b = {'b', }
	:param dict_a: 
	:param dict_b: 
	:return: 
	"""
	return {**dict_a, **dict_b}


def split(values, n):
	"""

	:param values:
	:param n:
	:return:
	"""
	k, m = divmod(len(values), n)
	return (values[i * k + min(i, m):(i+1) * k + min(i+1, m)] for i in range(n))
