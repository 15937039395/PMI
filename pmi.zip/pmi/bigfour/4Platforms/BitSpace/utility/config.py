#coding:utf-8

'''
Created on 2016年8月13日

@author: henry.huang
'''
import logging
import configparser
import codecs
import os
import platform


class ConfigHandler(object):
	"""docstring for ConfigHandler"""
	'''
	ini example:

	[DEFAULT]
	ip = 192.168.1.3
	dbname = Test

	[WEIBO]
	collection = Weibo
	tactic = 1
	input = /path/file
	output = /path/file
	'''
	def __init__(self, soure_file):
		super(ConfigHandler, self).__init__()
		self._config = configparser.RawConfigParser()
		self._soure_file = os.path.dirname(os.path.abspath(soure_file))
		#self._default_ini_file = default_ini_file
		#self._crawler_ini_file = crawler_ini_file
		self._logger = logging.getLogger('config')
		self._logger.info('ConfigHandler initialized')
		print(self._soure_file)

	def read_configure(self, ini_file, section):
		'''
		args: section, like 'WEIBO'
		return dict, like congfig[section]
		use example
		if ini section look like as
			[WEIBO]
			collection = Weibo
			tactic = 1
			input = /path
			output
		it will read all value of [section] and [DEFAULT] of ini file
		'''
		if platform.system() == 'Windows':
			self._config.readfp(codecs.open(self._soure_file+'\\'+ini_file, 'r', 'utf8'))
		elif platform.system() == 'Linux' or platform.system() == 'Darwin': #Linux or Mac
			self._config.readfp(codecs.open(self._soure_file+'/'+ini_file, 'r', 'utf8'))
		return self._config[section]
