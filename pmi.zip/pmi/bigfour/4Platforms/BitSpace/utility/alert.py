#coding:utf-8
import threading
import smtplib
import time
import os
import logging
# Import the email modules we'll need
from email.mime.text import MIMEText



class AlertHandler(object):
	"""
	docstring for AlertHandler.
	usr:hgdatacrawler@gmail.com,
	psw:hongguang
	"""
	def __init__(self, source_file, ip, port='25'):
		super(AlertHandler, self).__init__()
		self._logger = logging.getLogger('alert')
		self._soure_file_name = os.path.basename(source_file)
		self._ip = ip
		self._port = port
		self._from = 'CrawlerAlert'
		self._to = ['hgdatacrawler@gmail.com', 'henry.huang@hgdata.com.tw']
		self._cc = ['henry.huang@hgdata.com.tw']
		self._logger.info('AlertHandler initialized')

	def send_mail(self, msg, alarm_type):
		server = smtplib.SMTP(self._ip + ':' + self._port)
		server.ehlo()
		msg = MIMEText(msg)
		msg['Subject'] = '[' + alarm_type +']' + self._soure_file_name
		msg['from'] = self._from
		msg['to'] = ','.join(self._to)
		server.sendmail(self._from, self._to, msg.as_string())
		server.quit()
		print('alarm had been send mail')

	#It will be Deprecated later, because selenium had this similar API
	def wait_driver_get(self, timeout, _stop_event, url):
		'''
		interval : unit is second
		'''
		i = 0
		while i < int(timeout):
			print('waiting...')
			time.sleep(1)
			i = i + 1

		if not _stop_event.is_set():
			print('thread is not stop')
			_stop_event.set()
			message = 'Hi developers:\n\nThe web driver get \n\n' + url + '\n\nwas timeout,\n\nit maybe was blocked IP by this website or internet had not work.'
			self.send_mail(message, 'driver_get_timeout')
		else:
			print('thread had been stoped!!')


	def thd_init(self, timeout, url):
		self.thd_stop = threading.Event()
		thread = threading.Thread(target=self.wait_driver_get, args=(str(timeout), self.thd_stop, url))
		thread.daemon = True
		return thread

	def thd_quit(self):
		if not self.thd_stop.is_set():
			print('thread quit')
			self.thd_stop.set()

	def close(self):
		self._smtp_server.quit()
