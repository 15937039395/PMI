# coding: UTF-8

import logging

g_fmt = "[%(asctime)s][%(name)s][%(levelname)s]: %(message)s"


def set_level(level=logging.INFO):
	logging.basicConfig(level=level, format=g_fmt)


def tag(name):
	"""
	set the name of logger
	:param name:
	:return:
	"""
	logger = logging.getLogger(name=name)
	return logger
