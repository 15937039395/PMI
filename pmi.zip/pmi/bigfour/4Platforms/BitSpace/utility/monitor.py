#coding:utf-8

import time
import sys
import psutil
import platform
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

class PyQtMonitor(QWidget):
	def __init__(self):
		super(PyQtMonitor, self).__init__()
		self._platform = platform.system()
		self.initUI()
		self.update_crawler_table()
		self.timer = QTimer()
		self.timer.timeout.connect(self.update_crawler_table)
		self.timer.start(1000)


	def initUI(self):

		QToolTip.setFont(QFont('SansSerif', 12))
		crawler_header_h_list = ['name', 'pid', 'start time', 'status', 'cpu%', 'memory%', 'thread num', 'cmdline']

		self.setToolTip('This is a <b>QWidget</b> widget')
		self.quit_btn = QPushButton("Quit")
		self.quit_btn.clicked.connect(QCoreApplication.instance().quit)
		#self.quit_btn.clicked.connect(self.update_crawler_table)
		self.quit_btn.setToolTip('This is a <b>QPushButton</b> widget')
		self.quit_btn.resize(self.quit_btn.sizeHint())
		#quit_btn.move(50, 50)
		#ltv = self.get_process_list_view()
		self.crawler_tbv = QTableWidget(self)
		self.crawler_tbv.setColumnCount(8)
		self.crawler_tbv.setHorizontalHeaderLabels(crawler_header_h_list)
		#tbv = self.get_process_table_view()
		#lcd = QLCDNumber(self)
		#slid = QSlider(Qt.Horizontal, self)

		self.hbox = QHBoxLayout()
		self.hbox.addStretch(1)
		self.hbox.addWidget(self.quit_btn)

		self.vbox = QVBoxLayout()
		#vbox.addStretch(1)
		#vbox.addWidget(ltv)
		self.vbox.addWidget(self.crawler_tbv)
		#vbox.addWidget(lcd)
		#vbox.addWidget(slid)
		self.vbox.addLayout(self.hbox)

		self.setLayout(self.vbox)
		#slid.valueChanged.connect(lcd.display)

		self.setGeometry(100, 100, 1280, 720)
		self.setWindowTitle('Crawler process')
		self.setWindowIcon(QIcon('icon.png')) #It did not work

	def refresh_all_veiw():
		pass

	def get_process_list_view(self):
		list_view = QListWidget(self)

		for pid in psutil.pids():
			prcoess = psutil.Process(pid)
			try:
				print(prcoess.name())
				item = QListWidgetItem('Prcoess name: %s' % prcoess.name())
			except Exception as e:
				print('Exception')
				#raise
				continue

			list_view.addItem(item)

		return list_view

	def update_crawler_table(self):

		crawler_list = self.get_crawler_process()
		#self.crawler_tbv = QTableWidget(self)
		self.crawler_tbv.setRowCount(len(crawler_list))
		for i, p in enumerate(crawler_list):
			name_item = QTableWidgetItem(p.name())
			id_item = QTableWidgetItem(str(p.pid))
			start_item = QTableWidgetItem(str(time.strftime('%Y-%m-%d %H:%M:%S%z', time.gmtime(p.create_time()))))
			status_item = QTableWidgetItem(str(p.status()))
			cpu_item = QTableWidgetItem(str(p.cpu_percent()))
			memory_item = QTableWidgetItem(str(p.memory_percent()))
			thread_num_item = QTableWidgetItem(str(p.num_threads()))
			cmdline_item = QTableWidgetItem(str(p.cmdline()))

			self.crawler_tbv.setItem(i, 0, name_item)
			self.crawler_tbv.setItem(i, 1, id_item)
			self.crawler_tbv.setItem(i, 2, start_item)
			self.crawler_tbv.setItem(i, 3, status_item)
			self.crawler_tbv.setItem(i, 4, cpu_item)
			self.crawler_tbv.setItem(i, 5, memory_item)
			self.crawler_tbv.setItem(i, 6, thread_num_item)
			self.crawler_tbv.setItem(i, 7, cmdline_item)

		#adjust table item size
		self.crawler_tbv.resizeColumnsToContents()

	def get_crawler_process(self):
		crawler_list = []
		p_zombie = 0
		for i, pid in enumerate(psutil.pids()):
			prcoess = psutil.Process(pid)
			try:
				cmdline = prcoess.cmdline()
				if len(cmdline) == 2:
					if self._platform == 'Windows':
						if 'Crawler\\src\\' in cmdline[1]:
							#print(prcoess.cmdline())
							crawler_list.append(prcoess)
					elif self._platform == 'Linux' or self._platform == 'Darwin':
						if 'Crawler/src/' in cmdline[1]:
							#print(prcoess.cmdline())
							crawler_list.append(prcoess)
				else:
					continue

			except Exception as e:
				#print(str(e), 'i: %i' % i)
				p_zombie += 1
				#raise
				continue
		#print('zombie: %i ' % p_zombie)
		return crawler_list

	'''
	def closeEvent(self, event):
		reply = QMessageBox.question(self, 'Message',
			"Are you sure to quit?",
			QMessageBox.No, QMessageBox.Yes)
		if reply == QMessageBox.Yes:
			event.accept()
		else:
			event.ignore()
	'''

def main():
	app = QApplication(sys.argv)
	monitor = PyQtMonitor()
	monitor.show()
	sys.exit(app.exec_())

if __name__ == '__main__':
	main()
