#coding:utf-8
'''
Created on 2016年5月30日

@author: shane
'''

import logging
from logging.handlers import TimedRotatingFileHandler
import os


def init_logger(name, level):
	"""
	初始化root logger，並回傳模組使用之logger

	此功能僅限main function使用，若在模組內需使用logger，
	請直接: logging.getLogger(MODULE_NAME)
	來取得logger。

	Args:
		name: main function name
		level: logging level

	Returns:
		logger with specified module name
	"""

	formatter = logging.Formatter('[%(asctime)s][%(name)s][%(levelname)s] %(message)s')

	root_logger = logging.getLogger('')
	root_logger.setLevel(level)

	#console handler
	consoleHandler = logging.StreamHandler()
	consoleHandler.setLevel(level)
	consoleHandler.setFormatter(formatter)
	root_logger.addHandler(consoleHandler)

	#file handler
	if not os.path.isdir('logs'):
		os.mkdir('logs')

	fileHandler = TimedRotatingFileHandler('./logs/'+ name, when = 'midnight', encoding = 'UTF-8')
	fileHandler.suffix = '%Y-%m-%d.log'
	fileHandler.setLevel(level)
	fileHandler.setFormatter(formatter)
	root_logger.addHandler(fileHandler)

	return logging.getLogger(name)

def get_logger(name, level):
	'''
	準備滅亡!!!
	
	取得logger物件，並設定好console與file handler
	file handler將產生log file在./logs/log，每天一個log檔案

	Args:
		name: module/file name
		level: logging level
	Returns:
		logger 物件
	'''
	logger = logging.getLogger(name)
	logger.setLevel(level)

	formatter = logging.Formatter('[%(asctime)s][%(name)s][%(levelname)s] %(message)s')

	#console handler
	consoleHandler = logging.StreamHandler()
	consoleHandler.setLevel(level)
	consoleHandler.setFormatter(formatter)
	logger.addHandler(consoleHandler)

	#file handler
	if not os.path.isdir('logs'):
		os.mkdir('logs')

	fileHandler = TimedRotatingFileHandler('./logs/'+ name, when = 'midnight', encoding = 'UTF-8')
	fileHandler.suffix = '%Y-%m-%d.log'
	fileHandler.setLevel(level)
	fileHandler.setFormatter(formatter)
	logger.addHandler(fileHandler)

	return logger