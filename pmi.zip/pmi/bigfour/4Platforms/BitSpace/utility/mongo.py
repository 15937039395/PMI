# coding:utf-8

"""
Created on 2016年5月17日

@author: shane
"""

import logging
from datetime import datetime

from pymongo import MongoClient
import gridfs

GRIDFS_ERROR_CORRUPTGRIDFILE = '[Gridfs Error CorruptGridFile]'
GRIDFS_ERROR_NOFILE = '[Gridfs Error NoFile]'
GRIDFS_ERROR_FILEEXISTS = '[Gridfs Error FileExists]'
GRIDFS_ERROR_GRIDFSERROR = '[Gridfs Error GridFsError]'
OTHER_EXCEPTION = 'other exception:'

user = 'superuser'
password = 'hgd77287987'
authorization_db = 'admin'


class MongoHandler:
	"""
	操作MongoClient的物件類別
	"""

	def __init__(self, uri=None):
		"""

		:param ip:
		:param port:
		:param auth:
		"""
		self._logger = logging.getLogger('mongo')
		if uri is None:
			ip = 'localhost'
			port = 27017

		# uri = 'mongodb://' + user + ':' + password + '@' + ip + ':' + str(port) + '/' + authorization_db
		self._client = MongoClient(uri)

		self._inserted = 0
		self._updated = 0
		self._ignored = 0

		self._logger.info('MongoHandler initialized')

	def get_status(self):
		"""
		取得Mongo操作的統計資訊如：新增筆數、更新筆數、忽略筆數
		:return: 
		"""
		return {'inserted': self._inserted, 'updated': self._updated, 'ignored': self._ignored}

	def insert_crawler_status(self, db_name, status_info):
		status_info['inserted'] = self._inserted
		status_info['updated'] = self._updated
		status_info['ignored'] = self._ignored

		db = self._client[db_name]
		collection = db['CrawlerStatus']
		collection.insert_one(status_info)

	def count(self, db_name, collection_name, filter_dict):
		'''
		查詢資料筆數

		Args:
			db_name: DB名稱
			collection_name: collection名稱
			filter_dict: 篩選條件字典

		Returns:
			符合的資料筆數
		'''
		db = self._client[db_name]
		collection = db[collection_name]
		return collection.count(filter_dict)

	def find(self, db_name, collection_name, filter_dict, multi):
		'''
		查詢資料

		Args:
			db_name: DB名稱
			collection_name: collection名稱
			filter_dict: 篩選條件字典
			multi: 查詢後是否取得多筆資料

		Returns:
			若multi=True則回傳資料字典陣列；否則僅回傳一筆
		'''
		# self._logger.debug('finding')

		db = self._client[db_name]
		collection = db[collection_name]
		if (multi):
			return self.find_many(db_name, collection_name, filter_dict, None)
		# 			ary = []
		# 			for data in collection.find(filter_dict):
		# 				ary.append(data)
		#
		# 			return ary
		else:
			return collection.find_one(filter_dict)

	def find_many(self, db_name, collection_name, filter_dict, projection, page=1, limit=0):
		'''
		查詢資料

		Args:
			db_name: DB名稱
			collection_name: collection名稱
			filter_dict: 篩選條件字典
			projection: 篩選要那些欄位是否要顯示
			page: 從第幾頁開始
			limit: 每頁筆數

		Returns:
			回傳資料字典陣列
		'''

		db = self._client[db_name]
		collection = db[collection_name]

		skip = page * limit
		cursor = collection.find(filter=filter_dict, skip=skip, limit=limit, no_cursor_timeout=True,
		                         projection=projection)
		ary = list(cursor)
		cursor.close()
		# for data in collection.find(filter=filter_dict, skip=skip, limit=limit):
		#   ary.append(data)

		return ary

	def find_object_id(self, db_name, collection_name, filter_dict):
		'''
		取得符合篩選條件的單筆資料之 ObjectId

		Args:
			db_name: DB名稱
			collection_name: collection名稱
			filter_dict: 篩選條件字典

		Returns:
			若有找到則回傳 _id 之 ObjectId，否則回傳 None
		'''

		doc = self.find(db_name, collection_name, filter_dict, False)
		if doc != None:
			return doc['_id']
		else:
			return None

	def delete(self, db_name, collection_name, filter_dict, multi):
		'''
		刪除資料

		Args:
			db_name: DB名稱
			collection_name: collection名稱
			filter_dict: 篩選條件字典
			multi: 是否刪除多筆，True=刪除所有符合資料；否則僅刪除一筆
		'''
		self._logger.debug('deleting')

		db = self._client[db_name]
		collection = db[collection_name]
		if multi:
			collection.delete_many(filter_dict)
		else:
			collection.delete_one(filter_dict)

	def insert_many(self, db_name, collection_name, records, identifiers):
		'''
		新增多筆資料，分為以下幾種行為：
			1. 若資料不存在則新增
			2. 若資料存在，且資料有異動，則更新
			3. 若資料存在但資料無異動，則忽略

		Args:
			db_name: DB名稱
			collection_name: collection名稱
			record: 欲新增的資料字典
			identifiers: 用來判定唯一值的欄位陣列，用以判別資料是否重複
		'''
		self._logger.debug('inserting many')

		for record in records:
			self.insert_one(db_name, collection_name, record, identifiers)

	def insert_many2(self, db_name, collection_name, records, identifiers):
		'''
		'''
		self._logger.debug('inserting many 2')

		db = self._client[db_name]
		collection = db[collection_name]
		for record in records:
			today = datetime.today()
			record['createTime'] = today
			record['updateTime'] = today

		collection.insert_many(records)

	def insert_one(self, db_name, collection_name, record, identifiers):
		'''
		新增單筆資料，分為以下幾種行為：
			1. 若資料不存在則新增
			2. 若資料存在，且資料有異動，則更新
			3. 若資料存在但資料無異動，則忽略

		Args:
			db_name: DB名稱
			collection_name: collection名稱
			record: 欲新增的資料字典
			identifiers: 用來判定唯一值的欄位陣列，用以判別資料是否重複
		'''
		# self._logger.debug('inserting one')

		db = self._client[db_name]
		collection = db[collection_name]
		today = datetime.today()

		filter_dict = {}
		for field in identifiers:
			filter_dict[field] = record[field]

		doc = self.find(db_name, collection_name, filter_dict, False)
		if doc is None:
			record['createTime'] = today
			record['updateTime'] = today
			collection.insert_one(record)
			self._inserted += 1
		else:
			self._check_and_update(db_name, collection_name, doc, record)

	def _check_and_update(self, db_name, collection_name, doc, record):
		'''
		檢查檔案，若欄位有修改過則更新，否則不處理
		PS. 僅針對抓取欄位判斷，其餘欄位接忽略，以免誤判後製欄位

		Args:
			db_name: DB名稱
			collection_name: collection名稱
			doc: 從DB取出的資料字典
			record: 欲比較的資料字典
		'''
		# self._logger.debug('checking and updating')

		update_logs = []
		update_dict = {}

		for key in record.keys():
			if key not in doc.keys() or doc[key] != record[key]:
				old = None
				if key in doc.keys():
					old = repr(doc[key])
				update_logs.append({'field': key, 'old': old, 'new': repr(record[key])})
				update_dict[key] = record[key]

		if len(update_dict) > 0:
			# self._logger.debug('update')
			db = self._client[db_name]
			collection = db[collection_name]
			today = datetime.today()

			# 更新資料
			update_dict['updateTime'] = today
			collection.update_one({'_id': doc['_id']}, {'$set': update_dict})
			self._updated += 1

		# 更新狀態
		# log_dict = {'createTime': today, 'collection': collection_name, 'objId': doc['_id'], 'logs': update_logs}
		# log_collection = db['CrawlerLog']
		# log_collection.insert_one(log_dict)
		else:
			# self._logger.debug('Ignore')
			self._ignored += 1

	def gridfs_upload_from_stream(self, db_name, grid_fs_bucket, filename, source, metadata):
		'''
		return file id
		'''
		db = self._client[db_name]
		try:
			fsbk = gridfs.GridFSBucket(db, grid_fs_bucket)
			filed_id = fsbk.upload_from_stream(filename, source, metadata=metadata)
			return filed_id
		except gridfs.errors.NoFile as e:
			self._logger.exception(GRIDFS_ERROR_CORRUPTGRIDFILE + str(e))
			return None
		except gridfs.errors.FileExists as e:
			self._logger.exception(GRIDFS_ERROR_NOFILE + str(e))
			return None
		except gridfs.errors.CorruptGridFile as e:
			self._logger.exception(GRIDFS_ERROR_FILEEXISTS + str(e))
			return None
		except gridfs.errors.GridFSError as e:
			self._logger.exception(GRIDFS_ERROR_GRIDFSERROR + str(e))
			return None
		except Exception as e:
			self._logger.exception(OTHER_EXCEPTION + str(e))
			return None
		else:
			pass

	def distinct(self, db_name, collection_name, data_filter, key):
		"""

		:param db_name:
		:param collection_name:
		:param data_filter:
		:param key:
		:return:
		"""
		db = self._client[db_name]
		collection = db[collection_name]

		return collection.distinct(key, data_filter)

	def aggregate(self, db_name, collection_name, data_filter):
		"""

		:param db_name:
		:param collection_name:
		:param data_filter:
		:param key:
		:return:
		"""
		db = self._client[db_name]
		collection = db[collection_name]

		return list(collection.aggregate(data_filter))

	def data_check(self, db_name, collection_name, data_filter, multi, flag):
		"""
		this method is check data exist
		:param db_name:
		:param collection_name:
		:param docs:
		:param multi:
		:param flag:
		:return: list or doc
		"""
		if flag == "DEBUG":
			return self.find(db_name, collection_name, data_filter, multi)

	def data_confirm(self, db_name, collection_name, docs, identifiers, flag):
		"""
		if someone want data confirm, if flag is DEBUG, data will insert to db for data confirm
		:param db_name:
		:param collection_name:
		:param docs:
		:param identifiers:
		:param flag:
		:return:
		"""
		# print("flag:", flag)
		if flag == "DEBUG":
			# self._logger.debug("data confirm debug")
			if type(docs) is list:
				for doc in docs:
					self.insert_one(db_name, collection_name, doc, identifiers)
			else:
				self.insert_one(db_name, collection_name, docs, identifiers)

	def get_cursor(self, db_name, collection_name, data_filter):
		"""
		*attention* the cursor that return is no timeout, so remember close this cursor
		:param db_name:
		:param collection_name:
		:param data_filter:
		:return: a pymongo cursor
		"""
		db = self._client[db_name]
		collection = db[collection_name]
		return collection.find(data_filter, no_cursor_timeout=True)

	def close_disconnect(self):
		self._client.close()

	def project(self, db_name, collection_name, data_filter, projection):
		"""
		*attention* the cursor that return is no timeout, so remember close this cursor
		:param db_name:
		:param collection_name:
		:param data_filter:
		:param projection:
		:return: cursor_list
		"""
		if db_name in self._client.database_names():
			db = self._client[db_name]
		else:
			return []

		if collection_name in db.collection_names():
			collection = db[collection_name]
		else:
			return []
		cursor = collection.find(filter=data_filter, projection=projection, no_cursor_timeout=True)
		cursor_list = list(cursor)
		cursor.close()
		return cursor_list

	def projection_one(self, db_name, collection_name, data_filter, projection):
		"""

		:param db_name:
		:param collection_name:
		:param data_filter:
		:param projection:
		:return:
		"""
		if db_name in self._client.database_names():
			db = self._client[db_name]
		else:
			return None

		if collection_name in db.collection_names():
			collection = db[collection_name]
		else:
			return None

		doc = collection.find_one(filter=data_filter, projection=projection)
		return doc

	def collection_names(self, db_name=None):
		"""

		:param db_name:
		:return:
		"""
		return self._client[db_name].collection_names()

	def client(self):
		return self._client
