#!/bin/bash

collName=$1
platform="$(tr [:upper:] [:lower:] <<< "$collName")"

/usr/local/bin/python3.6 BitSpace/bit_space.py -query $collName -platform $platform -kind product -pre_collection Pre${CollName}Cate -dst_collection $collName --range 0,10

