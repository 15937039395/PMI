#!/bin/sh
/usr/local/bin/python3.6 /home/script/bigfour/4Platforms/BitSpace/bit_space.py -query Taobao -pre_collection PreTaobaoCate -dst_collection Taobao -platform taobao -kind product --range 0,10
