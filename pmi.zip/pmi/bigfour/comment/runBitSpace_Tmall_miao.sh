#!/bin/sh
/usr/local/bin/python3.6 /home/script/bigfour/comment/BitSpace/bit_space.py -query Tmall_miao_Fresh_Comment -platform tmall -kind comment -pre_collection Tmall_miao_Fresh_201803 -dst_collection Tmall_miao_Fresh_Comment_201803 --range 0,10 --term 2018-03-01 --search '{"majorTag":"fresh"}'
