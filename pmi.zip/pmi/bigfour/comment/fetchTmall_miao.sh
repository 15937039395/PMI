#!/bin/bash

/home/script/bigfour/comment/fetchBase.sh Tmall_miao
