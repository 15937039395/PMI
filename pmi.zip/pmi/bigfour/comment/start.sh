#!/bin/sh
#脚本数组集合
runBitSpaceAry=('runBitSpace_JD' 'runBitSpace_Taobao' 'runBitSpace_Tmall' 'runBitSpace_Yhd' )
nowDate=`date "+%Y-%m-%d"`
for((i=0;i<${#runBitSpaceAry[@]};i++))
do
{

#查找脚本进程是否存在,存在则kill
PROCESS=`ps -ef|grep ${runBitSpaceAry[i]}.sh|grep -v grep|grep -v PPID|awk '{ print $2}'`
for j in $PROCESS
do
echo "Kill the process [ $j ] ${runBitSpaceAry[i]}"
kill -9 $j  &>/dev/null
done
     
#执行脚本并输出日志文本
/root/routine/bigfour/${runBitSpaceAry[i]}.sh &>/dev/null
echo "${runBitSpaceAry[i]} OK" >>/root/routine/bigfour/Crontab_log/runBitSpace_${nowDate}.log 


#&多线程执行
} &
done
