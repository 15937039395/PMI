#!/bin/bash

/home/script/bigfour/Fresh/fetchBase.sh Tmall
