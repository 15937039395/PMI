#!/bin/sh
/usr/local/bin/python3.6 /home/script/bigfour/Fresh/BitSpace/bit_space.py -query Tmall_Fresh -pre_collection PreTmall_FreshCate -dst_collection Tmall_Fresh -platform tmall -kind product --range 0,10
