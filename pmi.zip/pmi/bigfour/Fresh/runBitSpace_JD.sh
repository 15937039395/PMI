#!/bin/sh
/usr/local/bin/python3.6 /home/script/bigfour/Fresh/BitSpace/bit_space.py -query JD_Fresh -pre_collection PreJD_FreshCate -dst_collection JD_Fresh -platform jd -kind product --range 0,10
