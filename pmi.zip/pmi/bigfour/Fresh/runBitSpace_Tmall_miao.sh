#!/bin/sh
/usr/local/bin/python3.6 /home/script/bigfour/Fresh/BitSpace/bit_space.py -query Tmall_miao_Fresh -pre_collection PreTmall_miao_FreshCate -dst_collection Tmall_miao_Fresh -platform tmall -kind product --searchType miao --range 0,10 
